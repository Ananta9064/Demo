import { useState } from "react";
import { Icon } from "./Icons";
import { SectionHead } from "./Bits";
import { AREAS, px } from "../lib/data";
import { Reveal, useQuote } from "../lib/ui";

export default function Areas() {
  const [active, setActive] = useState<string>(AREAS[0].code);
  const { requestQuote } = useQuote();

  return (
    <section id="areas" className="relative overflow-hidden py-20 sm:py-28">
      {/* subtle Bristol-themed background */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 bg-white" />
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <img
          src={px(15993243, 1400, 800)}
          alt=""
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover opacity-[0.07] grayscale-[35%]"
        />
      </div>
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 bg-gradient-to-b from-white via-white/85 to-white" />

      <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:gap-14">
        <div>
          <SectionHead
            eyebrow="Where we clean"
            title={
              <>
                Serving Bristol <br className="hidden sm:block" />&amp; surrounding areas
              </>
            }
            lead="Local, independent and always on time. Becky works across north, west and south Bristol — walking distance from the neighborhoods listed below, with regular customers on every one of these postcodes."
          />

          <ul className="mt-9 grid grid-cols-2 gap-3 sm:grid-cols-3">
            {AREAS.map((a, i) => {
              const isActive = active === a.code;
              return (
                <Reveal as="li" key={a.code} delay={i * 55}>
                  <button
                    type="button"
                    onMouseEnter={() => setActive(a.code)}
                    onFocus={() => setActive(a.code)}
                    onClick={() => requestQuote(undefined, a.code)}
                    aria-pressed={isActive}
                    className={`group flex w-full flex-col items-start gap-1 rounded-2xl border px-4 py-3.5 text-left transition-all duration-300 ${
                      isActive
                        ? "-translate-y-0.5 border-brand-600 bg-brand-600 text-white shadow-glow"
                        : "border-brand-900/10 bg-white text-ink hover:-translate-y-0.5 hover:border-brand-300 hover:bg-brand-50"
                    }`}
                  >
                    <span className="flex w-full items-center justify-between">
                      <span className="font-display text-[1.35rem] font-semibold leading-none">{a.code}</span>
                      <Icon
                        name="arrowRight"
                        size={15}
                        className={`transition-all duration-300 ${isActive ? "translate-x-0.5 opacity-100" : "-translate-x-1 opacity-0 group-hover:translate-x-0 group-hover:opacity-100"}`}
                      />
                    </span>
                    <span className={`text-[0.72rem] font-bold uppercase tracking-[0.1em] ${isActive ? "text-white/75" : "text-ink-mute"}`}>
                      {a.name}
                    </span>
                  </button>
                </Reveal>
              );
            })}
          </ul>

          <Reveal delay={120}>
            <div className="mt-8 flex flex-col gap-4 rounded-3xl bg-shell-deep p-5 sm:flex-row sm:items-center sm:justify-between">
              <p className="flex items-start gap-3 text-[0.95rem] leading-snug text-ink-soft">
                <Icon name="pin" size={19} className="mt-0.5 shrink-0 text-brand-600" />
                <span>
                  <span className="font-bold text-ink">Don&rsquo;t see your postcode?</span> Get in touch and ask about
                  availability in your area.
                </span>
              </p>
              <button type="button" onClick={() => requestQuote()} className="btn btn-primary sheen shrink-0 py-2.5! text-sm">
                Check my area
                <Icon name="arrowRight" size={15} className="btn-arrow" />
              </button>
            </div>
          </Reveal>
        </div>

        {/* hand-drawn style coverage map */}
        <Reveal delay={100}>
          <div className="relative">
            <div className="relative overflow-hidden rounded-[36px] border border-brand-100 bg-[#f3faf8] p-4 shadow-lift">
              <div className="flex items-center justify-between px-2 pb-3 pt-1">
                <p className="flex items-center gap-2 text-[0.68rem] font-bold uppercase tracking-[0.2em] text-brand-700">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-brand-500" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-brand-600" />
                  </span>
                  Coverage map
                </p>
                <p className="text-[0.68rem] font-bold uppercase tracking-[0.2em] text-ink-mute">Bristol · BS</p>
              </div>

              <svg viewBox="0 0 100 100" className="aspect-square w-full" role="img" aria-label="Map of the Bristol postcode areas covered by Becky's Cleaning Services">
                <defs>
                  <linearGradient id="land" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#ffffff" />
                    <stop offset="100%" stopColor="#e3f4f1" />
                  </linearGradient>
                </defs>

                {/* city blob */}
                <path
                  d="M14 34c5-16 22-24 38-22 15 2 27 10 31 24 4 13-2 26-13 35-12 10-29 13-42 7C14 72 9 52 14 34Z"
                  fill="url(#land)"
                  stroke="#b7e8e1"
                  strokeWidth="0.7"
                />

                {/* street grid */}
                <g stroke="#0e8c86" strokeOpacity="0.14" strokeWidth="0.5">
                  <path d="M18 46h64M22 58h56M26 34h48M40 22v56M54 20v60M66 28v48M30 26 20 62M74 26l8 32" />
                </g>
                {/* main roads */}
                <g stroke="#83d5cb" strokeWidth="1.6" strokeLinecap="round" fill="none">
                  <path d="M12 52c14-4 26-2 38 4s26 8 40 2" />
                  <path d="M46 14c-2 18 2 34 6 52" />
                </g>
                {/* river Avon */}
                <path
                  d="M8 68c12 6 20-6 30-2s10 12 22 10 18-10 32-8"
                  fill="none"
                  stroke="#9fd0e8"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  opacity="0.75"
                />
                <text x="14" y="76" fontSize="2.6" fill="#4d6b68" opacity="0.7" fontWeight="700" letterSpacing="0.6">
                  R. AVON
                </text>
                <text x="50" y="90" fontSize="3.4" fill="#0d2b29" opacity="0.35" fontWeight="700" letterSpacing="2.4" textAnchor="middle">
                  BRISTOL
                </text>

                {/* coverage radius */}
                <circle cx="46" cy="46" r="34" fill="none" stroke="#0e8c86" strokeOpacity="0.3" strokeWidth="0.5" strokeDasharray="2 3" />

                {/* pins */}
                {AREAS.map((a) => {
                  const on = active === a.code;
                  return (
                    <g key={a.code} transform={`translate(${a.x} ${a.y})`} className="cursor-pointer" onMouseEnter={() => setActive(a.code)} onFocus={() => setActive(a.code)} tabIndex={-1}>
                      {on && <circle r="7.5" fill="#0e8c86" opacity="0.14" className="animate-pulse-ring" />}
                      <circle r={on ? 4.6 : 3.4} fill={on ? "#0e8c86" : "#ffffff"} stroke={on ? "#0e5a58" : "#43bab0"} strokeWidth="1.1" style={{ transition: "all .35s cubic-bezier(.2,.7,.2,1)" }} />
                      <circle r="1.1" fill={on ? "#ffffff" : "#0e8c86"} />
                      <text
                        x="0"
                        y={on ? -7 : -5.6}
                        textAnchor="middle"
                        fontSize={on ? 4.2 : 3.4}
                        fontWeight="700"
                        fill={on ? "#0e5a58" : "#4d6b68"}
                        style={{ transition: "all .35s ease" }}
                      >
                        {a.code}
                      </text>
                    </g>
                  );
                })}
              </svg>

              <div className="mt-2 flex items-center justify-between gap-3 rounded-2xl bg-white px-4 py-3 ring-1 ring-brand-100">
                <p className="text-[0.85rem] font-semibold text-ink">
                  Active area:{" "}
                  <span className="text-brand-700">
                    {active} — {AREAS.find((a) => a.code === active)?.name}
                  </span>
                </p>
                <p className="hidden shrink-0 text-[0.7rem] font-bold uppercase tracking-[0.14em] text-ink-mute sm:block">
                  Tap a postcode to enquire
                </p>
              </div>
            </div>

            {/* georgian terrace accent */}
            <div className="absolute -bottom-6 -left-4 hidden w-44 overflow-hidden rounded-3xl border-4 border-white shadow-lift sm:block">
              <img
                src={px(37623824, 420, 300)}
                width={420}
                height={300}
                alt="A row of Georgian terraced houses typical of Bristol's residential streets"
                loading="lazy"
                decoding="async"
                className="h-28 w-full object-cover"
              />
              <p className="bg-white px-3 py-2 text-[0.7rem] font-bold uppercase tracking-[0.12em] text-ink-mute">
                Victorian &amp; Georgian homes, done right
              </p>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
