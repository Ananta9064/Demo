import { Icon } from "./Icons";
import { Logo } from "./Bits";
import {
  AREAS,
  BUSINESS,
  CONTACT,
  EMAIL_PLACEHOLDER,
  NAV,
  PHONE_PLACEHOLDER,
  emailHref,
  phoneHref,
} from "../lib/data";
import { Reveal, scrollToId, useQuote } from "../lib/ui";

const FOOTER_SERVICES = [
  { label: "House Cleaning", service: "House Cleaning" },
  { label: "Deep Cleaning", service: "Deep Cleaning" },
  { label: "Oven Cleaning", service: "Oven Cleaning" },
  { label: "End of Tenancy Cleaning", service: "End of Tenancy Cleaning" },
  { label: "Recurring Cleaning", service: "Recurring Home Cleaning" },
  { label: "Sanitization", service: "Disinfection & Sanitization" },
];

export default function Footer() {
  const { requestQuote } = useQuote();
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-brand-900/8 bg-shell pt-14">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        {/* CTA */}
        <Reveal>
          <div className="sheen relative mb-14 overflow-hidden rounded-[32px] bg-gradient-to-br from-brand-700 via-brand-600 to-brand-800 px-6 py-9 text-white sm:px-10">
            <div aria-hidden="true" className="paper pointer-events-none absolute inset-0 opacity-[0.14]" style={{ filter: "invert(1)" }} />
            <div className="relative flex flex-col items-start gap-6 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="u-eyebrow text-brand-100/90">Next clean</p>
                <h2 className="mt-3 max-w-xl font-display text-[clamp(1.6rem,4.6vw,2.4rem)] font-semibold leading-[1.08]">
                  Let&rsquo;s get your home booked in
                </h2>
                <p className="mt-3 max-w-lg text-[0.96rem] leading-relaxed text-brand-100/85">
                  One-off deep clean or a regular weekly visit — send a few details and you&rsquo;ll get a personalised
                  quote back.
                </p>
              </div>
              <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row lg:justify-end">
                <button type="button" onClick={() => requestQuote()} className="btn w-full bg-white text-brand-800 hover:-translate-y-0.5 sm:w-auto">
                  Get a Free Quote
                  <Icon name="arrowRight" size={16} className="btn-arrow" />
                </button>
                {phoneHref ? (
                  <a href={phoneHref} className="btn w-full border border-white/40 text-white hover:bg-white/10 sm:w-auto">
                    <Icon name="phone" size={16} /> {CONTACT.phone}
                  </a>
                ) : (
                  <span
                    title="Add the real number in src/lib/data.ts to activate"
                    className="btn w-full cursor-help border border-dashed border-white/40 text-white/80 sm:w-auto"
                  >
                    <Icon name="phone" size={16} /> {PHONE_PLACEHOLDER}
                  </span>
                )}
              </div>
            </div>
          </div>
        </Reveal>

        {/* columns */}
        <div className="grid gap-10 pb-12 sm:grid-cols-2 lg:grid-cols-[1.35fr_0.75fr_0.95fr_0.95fr]">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-[0.95rem] leading-relaxed text-ink-soft">{BUSINESS.strap}</p>
            <p className="mt-4 inline-flex items-center gap-2 rounded-full bg-white px-3.5 py-2 text-[0.75rem] font-bold uppercase tracking-[0.12em] text-brand-700 ring-1 ring-brand-100">
              <Icon name="badgeCheck" size={15} className="text-leaf-500" />
              Experienced cleaner &amp; housekeeper
            </p>
            <ul className="mt-5 flex flex-wrap gap-2">
              {AREAS.map((a) => (
                <li key={a.code}>
                  <span className="rounded-lg bg-white px-2.5 py-1 text-[0.75rem] font-bold text-ink-soft ring-1 ring-brand-100">
                    {a.code}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <nav aria-label="Footer navigation">
            <p className="u-eyebrow text-ink-mute">Quick Links</p>
            <ul className="mt-4 grid gap-2.5 text-[0.95rem] font-semibold">
              {NAV.map((n) => (
                <li key={n.id}>
                  <button
                    type="button"
                    onClick={() => scrollToId(n.id)}
                    className="link-underline text-ink-soft transition-colors hover:text-brand-700"
                  >
                    {n.id === "areas" ? "Areas" : n.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <p className="u-eyebrow text-ink-mute">Services</p>
            <ul className="mt-4 grid gap-2.5 text-[0.95rem] font-semibold">
              {FOOTER_SERVICES.map((s) => (
                <li key={s.label}>
                  <button
                    type="button"
                    onClick={() => requestQuote(s.service)}
                    className="group flex items-center gap-1.5 text-left text-ink-soft transition-colors hover:text-brand-700"
                  >
                    {s.label}
                    <Icon name="arrowRight" size={13} className="opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:opacity-100" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="u-eyebrow text-ink-mute">Talk to Becky</p>
            <ul className="mt-4 grid gap-3">
              <li>
                {phoneHref ? (
                  <a href={phoneHref} className="flex items-center gap-3 text-[0.95rem] font-semibold text-ink hover:text-brand-700">
                    <Icon name="phone" size={17} className="text-brand-600" /> {CONTACT.phone}
                  </a>
                ) : (
                  <span className="flex items-center gap-3 text-[0.95rem] font-semibold text-ink-mute">
                    <Icon name="phone" size={17} className="text-brand-400" /> {PHONE_PLACEHOLDER}
                  </span>
                )}
              </li>
              <li>
                {emailHref ? (
                  <a href={emailHref} className="flex items-center gap-3 break-all text-[0.95rem] font-semibold text-ink hover:text-brand-700">
                    <Icon name="mail" size={17} className="text-brand-600" /> {CONTACT.email}
                  </a>
                ) : (
                  <span className="flex items-center gap-3 break-all text-[0.95rem] font-semibold text-ink-mute">
                    <Icon name="mail" size={17} className="text-brand-400" /> {EMAIL_PLACEHOLDER}
                  </span>
                )}
              </li>
              <li className="flex items-center gap-3 text-[0.95rem] font-semibold text-ink-soft">
                <Icon name="pin" size={17} className="text-brand-600" /> {BUSINESS.location}
              </li>
            </ul>
            <button type="button" onClick={() => requestQuote()} className="btn btn-ghost mt-5 w-full py-2.5! text-sm">
              Request a Cleaning Quote
            </button>
          </div>
        </div>

        <div className="flex flex-col gap-3 border-t border-brand-900/8 pb-28 pt-7 text-[0.8rem] text-ink-mute sm:flex-row sm:items-center sm:justify-between lg:pb-8">
          <p>
            © {year} {BUSINESS.name}. Professional cleaning services in Bristol.
          </p>
          <p className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span>Serving Bristol since {BUSINESS.since}</span>
            <span className="hidden h-3 w-px bg-brand-900/15 sm:block" />
            <span className="font-semibold text-brand-700">Free demo website — contact details &amp; reviews awaiting Becky&rsquo;s input</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
