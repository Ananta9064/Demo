import { useState } from "react";
import { Icon } from "./Icons";
import { SectionHead, Tick } from "./Bits";
import { PRICING } from "../lib/data";
import { Reveal, useQuote } from "../lib/ui";

export default function Pricing() {
  const { requestQuote } = useQuote();

  return (
    <section id="pricing" className="relative overflow-hidden py-20 sm:py-28">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          backgroundImage:
            "radial-gradient(46% 40% at 12% 18%, rgba(168,217,174,0.22) 0%, rgba(168,217,174,0) 70%), radial-gradient(50% 44% at 88% 82%, rgba(67,186,176,0.16) 0%, rgba(67,186,176,0) 70%)",
        }}
      />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHead
          align="center"
          eyebrow="Rates"
          title="Simple, transparent pricing"
          lead="Two honest hourly rates. Tell Becky the property and the sort of clean you want and you'll get a fixed, personalised quote before anything is booked."
        />

        <div className="mx-auto mt-12 grid max-w-4xl gap-5 md:grid-cols-2">
          {PRICING.map((p, i) => (
            <Reveal key={p.name} delay={i * 110}>
              <article
                className={`card card-hover sheen relative flex h-full flex-col overflow-hidden p-7 sm:p-8 ${
                  p.highlight ? "border-brand-300! ring-1 ring-brand-200" : ""
                }`}
              >
                {p.highlight && (
                  <span className="absolute right-0 top-0 rounded-bl-2xl bg-brand-600 px-4 py-1.5 text-[0.68rem] font-bold uppercase tracking-[0.16em] text-white">
                    Most thorough
                  </span>
                )}

                <span
                  className={`grid h-12 w-12 place-items-center rounded-2xl ${
                    p.highlight ? "bg-brand-600 text-white" : "bg-brand-50 text-brand-700 ring-1 ring-brand-100"
                  }`}
                >
                  <Icon name={p.icon} size={23} />
                </span>

                <h3 className="mt-6 text-[1.05rem] font-bold uppercase tracking-[0.16em] text-brand-700">{p.name}</h3>

                <p className="mt-3 flex items-end gap-1.5">
                  <span className="font-display text-[clamp(3rem,10vw,4.1rem)] font-semibold leading-[0.85] text-ink">
                    {p.price}
                  </span>
                  <span className="pb-1.5 text-[1.05rem] font-bold text-ink-mute">{p.unit}</span>
                </p>

                <p className="mt-4 text-[1rem] font-medium leading-snug text-ink">{p.line}</p>

                <ul className="mt-6 grid gap-2.5 border-t border-brand-900/8 pt-6">
                  {p.points.map((pt) => (
                    <Tick key={pt}>{pt}</Tick>
                  ))}
                </ul>

                <button
                  type="button"
                  onClick={() => requestQuote(p.name)}
                  className={`btn mt-7 w-full ${p.highlight ? "btn-primary" : "btn-ghost"}`}
                >
                  Request a Quote
                  <Icon name="arrowRight" size={16} className="btn-arrow" />
                </button>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={80}>
          <div className="mx-auto mt-6 flex max-w-4xl flex-col items-center gap-4 rounded-[26px] border border-dashed border-brand-300 bg-white/70 px-6 py-6 text-center sm:flex-row sm:text-left">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-leaf-100 text-leaf-600">
              <Icon name="droplet" size={20} />
            </span>
            <p className="flex-1 text-[0.95rem] leading-relaxed text-ink-soft">
              <span className="font-bold text-ink">Prices shown are starting rates.</span> Contact Becky for a
              personalised quote based on your requirements — oven cleaning, end of tenancy and larger properties are
              quoted individually so you only pay for the work that is actually needed.
            </p>
            <button type="button" onClick={() => requestQuote()} className="btn btn-ink py-2.5! text-sm">
              Request a Quote
              <Icon name="arrowRight" size={15} className="btn-arrow" />
            </button>
          </div>
        </Reveal>

        <CostEstimator />
      </div>
    </section>
  );
}

const MIN_HOURS = 1;
const MAX_HOURS = 10;

function CostEstimator() {
  const [rate, setRate] = useState(17);
  const [hours, setHours] = useState(4);
  const { requestQuote } = useQuote();
  const total = rate * hours;
  const pct = ((hours - MIN_HOURS) / (MAX_HOURS - MIN_HOURS)) * 100;

  return (
    <Reveal delay={90}>
      <div className="mx-auto mt-6 max-w-4xl overflow-hidden rounded-[30px] border border-brand-100 bg-white shadow-soft">
        <div className="grid gap-8 p-6 sm:p-9 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div>
            <p className="u-eyebrow text-brand-700">Quick estimator</p>
            <h3 className="mt-3 text-[1.6rem] font-semibold leading-snug text-ink">
              How many hours do you think it needs?
            </h3>
            <p className="mt-2.5 text-[0.95rem] leading-relaxed text-ink-soft">
              Slide for an indicative figure — always confirmed in writing before anything is booked.
            </p>

            <div className="mt-6 inline-flex rounded-full bg-shell-deep p-1">
              {[
                { label: "General · £17/hr", value: 17 },
                { label: "Deep · £20/hr", value: 20 },
              ].map((o) => (
                <button
                  key={o.value}
                  type="button"
                  onClick={() => setRate(o.value)}
                  aria-pressed={rate === o.value}
                  className={`rounded-full px-4 py-2 text-[0.85rem] font-bold transition-all duration-300 ${
                    rate === o.value ? "bg-brand-600 text-white shadow-glow" : "text-ink-soft hover:text-brand-700"
                  }`}
                >
                  {o.label}
                </button>
              ))}
            </div>

            <label htmlFor="hours" className="mt-7 flex items-baseline justify-between text-[0.82rem] font-bold uppercase tracking-[0.12em] text-ink">
              Estimated time
              <span className="font-display text-[1.05rem] font-semibold tracking-normal text-brand-700 normal-case">
                {hours} {hours === 1 ? "hour" : "hours"}
              </span>
            </label>
            <input
              id="hours"
              type="range"
              min={MIN_HOURS}
              max={MAX_HOURS}
              step={1}
              value={hours}
              onChange={(e) => setHours(Number(e.target.value))}
              className="range mt-3"
              style={{ ["--pct" as string]: `${pct}%` }}
            />
            <div className="mt-2 flex justify-between text-[0.72rem] font-semibold text-ink-mute">
              <span>{MIN_HOURS} hr</span>
              <span>{MAX_HOURS} hrs</span>
            </div>
          </div>

          <div className="rounded-[24px] bg-gradient-to-br from-brand-50 via-white to-leaf-100/60 p-6 ring-1 ring-brand-100">
            <p className="text-[0.7rem] font-bold uppercase tracking-[0.16em] text-ink-mute">Indicative total</p>
            <p className="mt-2 flex items-end gap-2">
              <span className="font-display text-[3.1rem] font-semibold leading-none text-brand-800 tabular-nums">
                £{total}
              </span>
              <span className="pb-1 text-[0.85rem] font-bold text-ink-soft">
                {hours} × £{rate}
              </span>
            </p>
            <ul className="mt-5 grid gap-2 text-[0.86rem] leading-snug text-ink-soft">
              <li className="flex gap-2">
                <Icon name="clock" size={15} className="mt-0.5 shrink-0 text-brand-600" />
                The hourly rate covers the cleaning itself.
              </li>
              <li className="flex gap-2">
                <Icon name="leaf" size={15} className="mt-0.5 shrink-0 text-brand-600" />
                All-natural, non-toxic products wherever suitable.
              </li>
              <li className="flex gap-2">
                <Icon name="tag" size={15} className="mt-0.5 shrink-0 text-brand-600" />
                Add-ons like oven cleaning are quoted individually.
              </li>
            </ul>
            <button
              type="button"
              onClick={() => requestQuote(rate === 20 ? "Deep Cleaning" : "General Cleaning")}
              className="btn btn-primary sheen mt-6 w-full text-sm"
            >
              Request a Quote
              <Icon name="arrowRight" size={15} className="btn-arrow" />
            </button>
          </div>
        </div>
      </div>
    </Reveal>
  );
}
