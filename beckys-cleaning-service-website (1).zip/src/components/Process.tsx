import { Icon } from "./Icons";
import { SectionHead } from "./Bits";
import { STEPS } from "../lib/data";
import { Reveal, useQuote } from "../lib/ui";

export default function Process() {
  const { requestQuote } = useQuote();

  return (
    <section id="process" className="relative py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHead
          align="center"
          eyebrow="How it works"
          title="Three steps to a cleaner home"
          lead="No accounts, no portals, no pushy follow-ups. Just a quick message and a clear answer."
        />

        <div className="relative mt-14">
          {/* connector */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute left-[16%] right-[16%] top-[46px] hidden border-t-2 border-dashed border-brand-200 md:block"
          />
          <ol className="grid gap-6 md:grid-cols-3">
            {STEPS.map((s, i) => (
              <Reveal as="li" key={s.title} delay={i * 110}>
                <div className="group relative flex h-full flex-col items-start rounded-[30px] border border-brand-900/8 bg-white p-7 shadow-soft transition-all duration-500 hover:-translate-y-1.5 hover:border-brand-300 hover:shadow-lift">
                  <div className="flex w-full items-center justify-between">
                    <span className="relative grid h-[72px] w-[72px] place-items-center rounded-3xl bg-gradient-to-b from-brand-50 to-brand-100 text-brand-700 ring-1 ring-brand-200 transition-transform duration-500 group-hover:scale-105">
                      <Icon name={s.icon} size={30} strokeWidth={1.5} />
                      <span className="absolute -right-2 -top-2 grid h-8 w-8 place-items-center rounded-full bg-brand-600 font-display text-[0.95rem] font-semibold text-white shadow-glow">
                        {i + 1}
                      </span>
                    </span>
                    {i < STEPS.length - 1 && (
                      <Icon
                        name="arrowRight"
                        size={20}
                        className="hidden text-brand-300 transition-all duration-500 group-hover:translate-x-1 group-hover:text-brand-600 md:block"
                      />
                    )}
                  </div>
                  <h3 className="mt-6 text-[1.3rem] font-semibold leading-snug text-ink">{s.title}</h3>
                  <p className="mt-2.5 text-[0.96rem] leading-relaxed text-ink-soft">{s.text}</p>
                </div>
              </Reveal>
            ))}
          </ol>
        </div>

        <Reveal delay={120}>
          <div className="mx-auto mt-10 flex max-w-3xl flex-col items-center gap-4 rounded-[30px] bg-brand-950 px-6 py-8 text-center text-white sm:flex-row sm:justify-between sm:text-left">
            <div>
              <p className="font-display text-[1.35rem] font-semibold leading-tight">Step one takes about two minutes.</p>
              <p className="mt-1.5 text-[0.92rem] text-brand-100/80">
                Send your property size, postcode and the clean you need — you&rsquo;ll hear back with a quote.
              </p>
            </div>
            <button type="button" onClick={() => requestQuote()} className="btn sheen w-full shrink-0 bg-white text-brand-800 hover:-translate-y-0.5 sm:w-auto">
              Get a Free Quote
              <Icon name="arrowRight" size={16} className="btn-arrow" />
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
