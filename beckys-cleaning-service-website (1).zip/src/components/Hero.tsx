import { useEffect, useState } from "react";
import { Icon } from "./Icons";
import { Bubbles } from "./Bits";
import { BUSINESS, TRUST, px } from "../lib/data";
import { Reveal, scrollToId, useQuote } from "../lib/ui";

export default function Hero() {
  const { requestQuote } = useQuote();
  const [shift, setShift] = useState(0);

  /* gentle parallax on the hero photograph */
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => setShift(Math.min(window.scrollY, 640)));
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <section id="home" className="relative overflow-hidden pt-[104px] sm:pt-[112px]">
      {/* layered ambient background */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 bg-white" />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[720px]"
        style={{
          backgroundImage:
            "radial-gradient(60% 55% at 78% 6%, rgba(67,186,176,0.20) 0%, rgba(67,186,176,0) 68%), radial-gradient(48% 46% at 4% 26%, rgba(168,217,174,0.28) 0%, rgba(168,217,174,0) 70%)",
        }}
      />
      <div aria-hidden="true" className="paper pointer-events-none absolute inset-0 -z-10 opacity-60 [mask-image:linear-gradient(to_bottom,black,transparent_88%)]" />
      <Bubbles className="-z-10 opacity-70" count={8} />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="grid items-center gap-10 py-10 sm:py-14 lg:grid-cols-[1.02fr_0.98fr] lg:gap-14 lg:py-16">
          {/* ── copy ── */}
          <div>
            <Reveal>
              <span className="inline-flex items-center gap-2.5 rounded-full border border-brand-200 bg-white/80 py-1.5 pl-2 pr-4 text-[0.72rem] font-bold uppercase tracking-[0.16em] text-brand-700 shadow-soft backdrop-blur">
                <span className="grid h-6 w-6 place-items-center rounded-full bg-gradient-to-b from-brand-500 to-brand-700 text-white">
                  <Icon name="sparkle" size={13} strokeWidth={1.8} />
                </span>
                Serving Bristol · Since {BUSINESS.since}
              </span>
            </Reveal>

            <h1 className="mt-6 text-[clamp(2.15rem,8.4vw,4.15rem)] font-semibold leading-[0.98] text-ink">
              <Reveal as="span" delay={40} className="block">
                <span className="block">Professional Cleaning</span>
              </Reveal>
              <Reveal as="span" delay={110} className="block">
                <span className="block">
                  Services in{" "}
                  <span className="relative inline-block font-display italic text-brand-700">
                    Bristol
                    <svg
                      viewBox="0 0 240 14"
                      className="absolute -bottom-1.5 left-0 h-[10px] w-full text-brand-300"
                      preserveAspectRatio="none"
                      aria-hidden="true"
                    >
                      <path d="M3 10.5C62 3.2 176 2.4 237 7.6" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                    </svg>
                  </span>
                </span>
              </Reveal>
            </h1>

            <Reveal delay={180}>
              <p className="mt-7 max-w-xl text-[1.12rem] font-medium leading-snug text-ink">
                Reliable, flexible and professional home cleaning tailored to your needs.
              </p>
            </Reveal>
            <Reveal delay={230}>
              <p className="mt-3 max-w-xl text-[1rem] leading-relaxed text-ink-soft">
                From regular home cleaning to deep cleans and end of tenancy cleaning, Becky&rsquo;s Cleaning
                Services helps keep your home fresh, clean and comfortable.
              </p>
            </Reveal>

            <Reveal delay={300}>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
                <button type="button" onClick={() => requestQuote()} className="btn btn-primary sheen w-full sm:w-auto">
                  Get a Free Quote
                  <Icon name="arrowRight" size={17} className="btn-arrow" />
                </button>
                <button
                  type="button"
                  onClick={() => scrollToId("services")}
                  className="btn btn-ghost w-full sm:w-auto"
                >
                  View Our Services
                </button>
              </div>
            </Reveal>

            <Reveal delay={360}>
              <ul className="mt-9 grid gap-x-6 gap-y-3 border-t border-brand-900/8 pt-6 text-sm font-semibold text-ink sm:grid-cols-2">
                {[
                  { icon: "clock" as const, t: "One-off to monthly schedules" },
                  { icon: "leaf" as const, t: "All-natural, non-toxic products" },
                  { icon: "tag" as const, t: "General cleaning from £17/hr" },
                  { icon: "badgeCheck" as const, t: "Experienced cleaner & housekeeper" },
                ].map((f) => (
                  <li key={f.t} className="flex items-center gap-2.5">
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-leaf-100 text-leaf-600">
                      <Icon name={f.icon} size={16} strokeWidth={1.7} />
                    </span>
                    {f.t}
                  </li>
                ))}
              </ul>
            </Reveal>
          </div>

          {/* ── imagery ── */}
          <div className="relative">
            <Reveal delay={140} className="relative">
              <div className="relative overflow-hidden rounded-[38px] rounded-tr-[110px] border border-white bg-shell-deep shadow-lift">
                <img
                  src={px(8146213, 1000, 1150)}
                  srcSet={`${px(8146213, 640, 736)} 640w, ${px(8146213, 900, 1035)} 900w, ${px(8146213, 1100, 1265)} 1100w`}
                  sizes="(min-width: 1024px) 46vw, 92vw"
                  width={1000}
                  height={1150}
                  alt="A bright, freshly cleaned modern living room in a Bristol home with sunlight through large windows"
                  style={{ transform: `translate3d(0, ${shift * 0.02}px, 0) scale(1.08)`, willChange: "transform" }}
                  className="h-[clamp(340px,54vw,560px)] w-full origin-center object-cover"
                  loading="eager"
                  decoding="async"
                  fetchPriority="high"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-brand-950/25 via-transparent to-transparent" />
              </div>
            </Reveal>

            {/* floating detail card */}
            <Reveal delay={260} className="absolute -bottom-6 left-1 w-[63%] max-w-[280px] sm:-left-6">
              <figure className="card overflow-hidden rounded-3xl! p-2.5">
                <div className="flex items-center gap-3">
                  <img
                    src={px(6466227, 220, 220)}
                    width={220}
                    height={220}
                    alt="Freshly folded clean towels laid out after a housekeeping visit"
                    className="h-14 w-14 shrink-0 rounded-2xl object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                  <figcaption className="pr-1">
                    <p className="font-display text-[0.95rem] font-semibold leading-tight text-ink">
                      Left exactly as it should be
                    </p>
                    <p className="mt-1 text-[0.72rem] font-semibold uppercase tracking-[0.14em] text-brand-600">
                      Finishing touches included
                    </p>
                  </figcaption>
                </div>
              </figure>
            </Reveal>

            {/* availability chip */}
            <Reveal delay={340} className="absolute -top-3 right-0 sm:-right-4">
              <div className="animate-floaty-slow rounded-2xl border border-brand-100 bg-white/95 px-3.5 py-2.5 shadow-soft backdrop-blur">
                <p className="flex items-center gap-2 text-[0.72rem] font-bold uppercase tracking-[0.12em] text-ink">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-leaf-500" />
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-leaf-500" />
                  </span>
                  Last-minute slots may be open
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>

      {/* trust marquee */}
      <div className="relative mt-4 overflow-hidden border-y border-brand-900/8 bg-brand-950 py-3.5 sm:mt-8">
        <div className="pause-on-hover flex w-max animate-marquee items-center">
          {[0, 1].map((copy) => (
            <div key={copy} className="flex shrink-0 items-center gap-10 pr-10" aria-hidden={copy === 1}>
              {TRUST.map((t, i) => (
                <span
                  key={i}
                  className="flex items-center gap-3 whitespace-nowrap text-[0.78rem] font-bold uppercase tracking-[0.2em] text-brand-100/90"
                >
                  <Icon name="sparkle" size={14} className="text-brand-300" />
                  {t}
                </span>
              ))}
            </div>
          ))}
        </div>
        <div className="pointer-events-none absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-brand-950 to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-brand-950 to-transparent" />
      </div>
    </section>
  );
}
