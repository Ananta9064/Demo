import { Icon } from "./Icons";
import { SectionHead } from "./Bits";
import { TESTIMONIALS } from "../lib/data";
import { Reveal, useQuote } from "../lib/ui";

/**
 * DEMO NOTICE — these are deliberately empty placeholders.
 * Replace `quote` in src/lib/data.ts with real reviews (with the
 * customer's permission) and delete the hint line when you do.
 */
export default function Testimonials() {
  const { requestQuote } = useQuote();

  return (
    <section id="reviews" className="relative overflow-hidden bg-shell py-20 sm:py-28">
      <div aria-hidden="true" className="paper pointer-events-none absolute inset-0 opacity-50" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <SectionHead
            eyebrow="Customer feedback"
            title={
              <>
                What customers <span className="italic text-brand-700">say</span>
              </>
            }
            lead="Review space is set up and ready — Becky can drop in genuine feedback from Bristol customers as it comes in."
          />
          <Reveal delay={140}>
            <span className="inline-flex items-center gap-2 self-start rounded-full border border-dashed border-brand-300 bg-white px-3.5 py-2 text-[0.72rem] font-bold uppercase tracking-[0.14em] text-brand-700">
              <Icon name="sparkle" size={14} />
              Placeholder content
            </span>
          </Reveal>
        </div>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={i} delay={i * 100}>
              <figure className="card card-hover flex h-full flex-col p-7">
                <div className="flex items-start justify-between">
                  <span className="grid h-11 w-11 place-items-center rounded-2xl bg-brand-50 text-brand-600">
                    <Icon name="quote" size={22} strokeWidth={1.4} />
                  </span>
                  <span className="rounded-full bg-shell-deep px-2.5 py-1 text-[0.62rem] font-bold uppercase tracking-[0.14em] text-ink-mute">
                    {t.label}
                  </span>
                </div>
                <blockquote className="mt-6 flex-1">
                  <p className="border-b border-dashed border-brand-900/12 pb-6 font-display text-[1.32rem] font-medium italic leading-snug text-ink/55">
                    &ldquo;{t.quote}&rdquo;
                  </p>
                </blockquote>
                <figcaption className="mt-5 flex items-center gap-3">
                  <span className="grid h-9 w-9 place-items-center rounded-full bg-brand-100 text-[0.8rem] font-bold text-brand-700">
                    ?
                  </span>
                  <span className="text-[0.85rem] font-semibold leading-tight text-ink-mute">
                    Customer name · BS postcode
                    <span className="mt-1 block text-[0.78rem] font-normal italic text-ink-mute/85">{t.hint}</span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        <Reveal delay={100}>
          <div className="mt-6 flex flex-col items-start gap-4 rounded-[26px] border border-brand-100 bg-white p-5 sm:flex-row sm:items-center sm:justify-between">
            <p className="flex items-center gap-3 text-[0.9rem] leading-snug text-ink-soft">
              <Icon name="chat" size={19} className="shrink-0 text-brand-600" />
              Happy with a clean? Becky would love a short review to feature here — genuine feedback only.
            </p>
            <button type="button" onClick={() => requestQuote()} className="btn btn-ghost py-2.5! text-sm shrink-0">
              Contact Becky
              <Icon name="arrowRight" size={15} className="btn-arrow" />
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
