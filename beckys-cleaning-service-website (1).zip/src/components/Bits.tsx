import type { ReactNode } from "react";
import { Icon, type IconName } from "./Icons";
import { Reveal } from "../lib/ui";

/* ---------------------------- logo ---------------------------- */
export function Logo({ tone = "ink", compact = false }: { tone?: "ink" | "light"; compact?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <span className="relative grid h-10 w-10 shrink-0 place-items-center rounded-[13px] bg-gradient-to-b from-brand-500 to-brand-700 text-white shadow-[0_10px_22px_-12px_rgba(14,140,134,0.9)]">
        <Icon name="sparkle" size={21} strokeWidth={1.5} />
        <span className="absolute -right-0.5 -bottom-0.5 h-2.5 w-2.5 rounded-full bg-leaf-300 ring-2 ring-white" />
      </span>
      <span className="flex flex-col leading-none">
        <span
          className={`font-display text-[1.06rem] font-semibold tracking-[-0.01em] ${
            tone === "light" ? "text-white" : "text-ink"
          }`}
        >
          Becky&rsquo;s Cleaning
        </span>
        {!compact && (
          <span
            className={`mt-1 text-[0.6rem] font-bold uppercase tracking-[0.28em] ${
              tone === "light" ? "text-white/70" : "text-brand-600"
            }`}
          >
            Services
          </span>
        )}
      </span>
    </span>
  );
}

/* ------------------------- section head ------------------------- */
export function SectionHead({
  eyebrow,
  title,
  lead,
  align = "left",
  tone = "ink",
  tail,
}: {
  eyebrow: string;
  title: ReactNode;
  lead?: ReactNode;
  align?: "left" | "center";
  tone?: "ink" | "light";
  tail?: ReactNode;
}) {
  const isCenter = align === "center";
  return (
    <div className={`max-w-2xl ${isCenter ? "mx-auto text-center" : ""}`}>
      <Reveal>
        <span
          className={`inline-flex items-center gap-2 u-eyebrow ${
            tone === "light" ? "text-brand-200" : "text-brand-600"
          }`}
        >
          <span className={`h-px w-7 ${tone === "light" ? "bg-brand-200/60" : "bg-brand-300"}`} />
          {eyebrow}
        </span>
      </Reveal>
      <Reveal delay={60}>
        <h2
          className={`mt-4 text-[clamp(1.85rem,5.4vw,3.1rem)] font-semibold leading-[1.06] ${
            tone === "light" ? "text-white" : "text-ink"
          }`}
        >
          {title}
        </h2>
      </Reveal>
      {lead && (
        <Reveal delay={120}>
          <p className={`mt-5 text-[1.02rem] leading-relaxed ${tone === "light" ? "text-brand-100/85" : "text-ink-soft"}`}>{lead}</p>
        </Reveal>
      )}
      {tail && <Reveal delay={180}>{tail}</Reveal>}
    </div>
  );
}

/* ---------------------------- chips ---------------------------- */
export function IconChip({ name, className = "" }: { name: IconName; className?: string }) {
  return (
    <span
      className={`relative grid place-items-center rounded-2xl bg-brand-50 text-brand-700 ring-1 ring-brand-100 transition-transform duration-500 group-hover:scale-[1.06] group-hover:-rotate-3 ${className}`}
    >
      <Icon name={name} size={24} />
    </span>
  );
}

export function Tick({ children }: { children: ReactNode }) {
  return (
    <li className="flex items-start gap-2.5 text-[0.95rem] leading-snug text-ink-soft">
      <span className="mt-0.5 grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full bg-leaf-100 text-leaf-600">
        <Icon name="check" size={11} strokeWidth={2.6} />
      </span>
      <span>{children}</span>
    </li>
  );
}

/* ------------------------- ambient bubbles ------------------------- */
export function Bubbles({ count = 7, className = "" }: { count?: number; className?: string }) {
  const bubbles = Array.from({ length: count }, (_, i) => {
    const size = 10 + ((i * 37) % 46);
    const left = (i * 97) % 92;
    const top = (i * 53) % 88;
    const dur = 8 + ((i * 13) % 9);
    return { size, left, top, dur, i };
  });
  return (
    <div className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`} aria-hidden="true">
      {bubbles.map((b) => (
        <span
          key={b.i}
          className="absolute rounded-full border border-brand-200/70 bg-gradient-to-br from-white/70 to-brand-100/40 backdrop-blur-[1px] animate-floaty"
          style={{
            width: b.size,
            height: b.size,
            left: `${b.left}%`,
            top: `${b.top}%`,
            animationDuration: `${b.dur}s`,
            animationDelay: `${b.i * 0.7}s`,
          }}
        />
      ))}
    </div>
  );
}
