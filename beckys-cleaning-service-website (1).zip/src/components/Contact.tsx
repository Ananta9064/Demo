import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Icon, Spinner } from "./Icons";
import { SectionHead } from "./Bits";
import {
  AREAS,
  CONTACT,
  EMAIL_PLACEHOLDER,
  PHONE_PLACEHOLDER,
  SERVICE_OPTIONS,
  emailHref,
  phoneHref,
} from "../lib/data";
import { Reveal, useQuote } from "../lib/ui";

type Values = {
  name: string;
  email: string;
  phone: string;
  postcode: string;
  service: string;
  date: string;
  message: string;
};

const EMPTY: Values = { name: "", email: "", phone: "", postcode: "", service: "", date: "", message: "" };

const QUICK = ["House Cleaning", "Deep Cleaning", "End of Tenancy Cleaning", "Oven Cleaning"];

export default function Contact() {
  const { service, setService, postcode, setPostcode, highlight } = useQuote();
  const [values, setValues] = useState<Values>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof Values, string>>>({});
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const formRef = useRef<HTMLFormElement>(null);

  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);

  useEffect(() => {
    if (service) setValues((v) => ({ ...v, service }));
  }, [service]);
  useEffect(() => {
    if (postcode) setValues((v) => ({ ...v, postcode: postcode }));
  }, [postcode]);

  const set = (key: keyof Values) => (raw: string) => {
    setValues((v) => ({ ...v, [key]: raw }));
    setErrors((e) => ({ ...e, [key]: undefined }));
    if (key === "service") setService(raw);
    if (key === "postcode") setPostcode(raw.toUpperCase());
  };

  const validate = () => {
    const e: Partial<Record<keyof Values, string>> = {};
    if (values.name.trim().length < 2) e.name = "Please pop your name in.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(values.email.trim())) e.email = "Please enter a valid email address.";
    if (values.phone.trim() && values.phone.replace(/\D/g, "").length < 9)
      e.phone = "That number looks a little short.";
    if (!/^[a-z]{1,2}\d[a-z]?(\s?\d[a-z]{2})?$/i.test(values.postcode.trim()))
      e.postcode = "Please add your postcode — e.g. BS6 or BS6 9PT.";
    if (!values.service) e.service = "Choose the clean you need.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const onSubmit = (ev: FormEvent) => {
    ev.preventDefault();
    if (!validate()) {
      const first = formRef.current?.querySelector<HTMLElement>('[data-error="true"]');
      first?.focus();
      first?.scrollIntoView({ block: "center", behavior: "smooth" });
      return;
    }
    setStatus("sending");
    window.setTimeout(() => setStatus("sent"), 1200);
  };

  return (
    <section id="contact" className="relative overflow-hidden py-20 sm:py-28">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 bg-brand-950" />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10 opacity-90"
        style={{
          backgroundImage:
            "radial-gradient(46% 42% at 88% 4%, rgba(67,186,176,0.42) 0%, rgba(67,186,176,0) 68%), radial-gradient(40% 40% at 6% 92%, rgba(79,169,106,0.34) 0%, rgba(79,169,106,0) 70%)",
        }}
      />
      <div aria-hidden="true" className="paper pointer-events-none absolute inset-0 -z-10 opacity-[0.12]" style={{ filter: "invert(1)" }} />

      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHead
          tone="light"
          eyebrow="Get in touch"
          title="Ready for a cleaner home?"
          lead="Tell us what you need and we'll be happy to discuss your cleaning requirements."
        />

        <div className="mt-12 grid items-start gap-6 lg:grid-cols-[1.25fr_0.75fr]">
          {/* ── form ── */}
          <Reveal>
            <div
              className={`relative rounded-[34px] bg-white p-5 shadow-lift transition-all duration-500 sm:p-8 ${
                highlight ? "ring-4 ring-leaf-300/70" : "ring-0 ring-transparent"
              }`}
            >
              {status === "sent" ? (
                <div className="py-6 text-center sm:py-10">
                  <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-leaf-100 text-leaf-600">
                    <Icon name="check" size={30} strokeWidth={2.2} />
                  </span>
                  <h3 className="mt-6 font-display text-[1.7rem] font-semibold leading-tight text-ink">
                    Thanks {values.name.split(" ")[0]} — that&rsquo;s your enquiry ready.
                  </h3>
                  <p className="mx-auto mt-3 max-w-md text-[0.96rem] leading-relaxed text-ink-soft">
                    This is a demo website, so the form is not connected to an inbox yet. Once Becky adds her email
                    and phone number, requests like this arrive with her directly.
                  </p>
                  <dl className="mx-auto mt-7 grid max-w-lg gap-px overflow-hidden rounded-2xl bg-brand-900/8 text-left sm:grid-cols-2">
                    {[
                      ["Service", values.service],
                      ["Postcode", values.postcode],
                      ["Preferred date", values.date || "Flexible"],
                      ["Contact", values.email],
                    ].map(([k, v]) => (
                      <div key={k} className="bg-white px-4 py-3">
                        <dt className="text-[0.66rem] font-bold uppercase tracking-[0.16em] text-ink-mute">{k}</dt>
                        <dd className="mt-1 text-[0.94rem] font-semibold text-ink">{v || "—"}</dd>
                      </div>
                    ))}
                  </dl>
                  <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
                    <button
                      type="button"
                      className="btn btn-ghost"
                      onClick={() => {
                        setStatus("idle");
                        setValues(EMPTY);
                        setService("");
                        setPostcode("");
                      }}
                    >
                      Send another request
                    </button>
                    {phoneHref ? (
                      <a href={phoneHref} className="btn btn-primary">
                        <Icon name="phone" size={16} /> Call instead
                      </a>
                    ) : (
                      <span className="btn btn-primary pointer-events-none opacity-60" title="Add the real number in src/lib/data.ts">
                        <Icon name="phone" size={16} /> {PHONE_PLACEHOLDER}
                      </span>
                    )}
                  </div>
                </div>
              ) : (
                <>
                  <form ref={formRef} onSubmit={onSubmit} noValidate className="grid gap-4">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Field label="Name" id="name" error={errors.name} required>
                        <input
                          id="name"
                          name="name"
                          autoComplete="name"
                          placeholder="Your name"
                          className="field"
                          value={values.name}
                          data-error={errors.name ? "true" : "false"}
                          onChange={(e) => set("name")(e.target.value)}
                        />
                      </Field>
                      <Field label="Email" id="email" error={errors.email} required>
                        <input
                          id="email"
                          name="email"
                          type="email"
                          inputMode="email"
                          autoComplete="email"
                          placeholder="you@example.com"
                          className="field"
                          value={values.email}
                          data-error={errors.email ? "true" : "false"}
                          onChange={(e) => set("email")(e.target.value)}
                        />
                      </Field>
                      <Field label="Phone" id="phone" error={errors.phone} hint="optional">
                        <input
                          id="phone"
                          name="phone"
                          type="tel"
                          inputMode="tel"
                          autoComplete="tel"
                          placeholder="UK mobile or landline"
                          className="field"
                          value={values.phone}
                          data-error={errors.phone ? "true" : "false"}
                          onChange={(e) => set("phone")(e.target.value)}
                        />
                      </Field>
                      <Field label="Postcode" id="postcode" error={errors.postcode} required>
                        <input
                          id="postcode"
                          name="postcode"
                          autoComplete="postal-code"
                          autoCapitalize="characters"
                          placeholder="e.g. BS6 9PT"
                          className="field"
                          value={values.postcode}
                          data-error={errors.postcode ? "true" : "false"}
                          onChange={(e) => set("postcode")(e.target.value)}
                        />
                      </Field>
                      <Field label="Cleaning Service" id="service" error={errors.service} required>
                        <div className="relative">
                          <select
                            id="service"
                            name="service"
                            className="field appearance-none pr-11"
                            value={values.service}
                            data-error={errors.service ? "true" : "false"}
                            onChange={(e) => set("service")(e.target.value)}
                          >
                            <option value="">Select a service…</option>
                            {SERVICE_OPTIONS.map((o) => (
                              <option key={o} value={o}>
                                {o}
                              </option>
                            ))}
                          </select>
                          <Icon
                            name="chevron"
                            size={17}
                            className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-brand-600"
                          />
                        </div>
                      </Field>
                      <Field label="Preferred Date" id="date" hint="optional">
                        <input
                          id="date"
                          name="date"
                          type="date"
                          min={today}
                          className="field"
                          value={values.date}
                          onChange={(e) => set("date")(e.target.value)}
                        />
                      </Field>
                    </div>

                    <Field label="Message" id="message" hint="the more detail, the sharper the quote">
                      <textarea
                        id="message"
                        name="message"
                        rows={5}
                        placeholder="2-bed terrace near Redland, one bathroom. Need a deep clean including inside the oven and cupboards — pets in the house."
                        className="field resize-y"
                        value={values.message}
                        onChange={(e) => set("message")(e.target.value)}
                      />
                    </Field>

                    <div className="mt-1 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <p className="order-2 flex items-start gap-2 text-[0.8rem] leading-snug text-ink-mute sm:order-1 sm:max-w-[22rem]">
                        <Icon name="shieldLeaf" size={16} className="mt-0.5 shrink-0 text-brand-600" />
                        Your details are only used to reply to this enquiry. Nothing is shared with anyone else.
                      </p>
                      <button type="submit" className="btn btn-primary sheen order-1 w-full sm:order-2 sm:w-auto" disabled={status === "sending"}>
                        {status === "sending" ? (
                          <>
                            <Spinner /> Sending…
                          </>
                        ) : (
                          <>
                            Request a Free Quote
                            <Icon name="arrowRight" size={16} className="btn-arrow" />
                          </>
                        )}
                      </button>
                    </div>
                  </form>

                  <div className="mt-6 border-t border-brand-900/8 pt-5">
                    <p className="text-[0.7rem] font-bold uppercase tracking-[0.16em] text-ink-mute">In a hurry? Pick a service:</p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {QUICK.map((q) => (
                        <button
                          key={q}
                          type="button"
                          onClick={() => set("service")(q)}
                          className={`rounded-full border px-3.5 py-1.5 text-[0.82rem] font-semibold transition-all duration-300 ${
                            values.service === q
                              ? "border-brand-600 bg-brand-600 text-white"
                              : "border-brand-200 bg-white text-brand-800 hover:-translate-y-0.5 hover:border-brand-400 hover:bg-brand-50"
                          }`}
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </Reveal>

          {/* ── details ── */}
          <div className="grid gap-4">
            <Reveal delay={90}>
              <div className="rounded-[30px] border border-white/15 bg-white/8 p-6 text-white backdrop-blur-md">
                <p className="u-eyebrow text-brand-200">Contact details</p>
                <p className="mt-3 flex items-center gap-2 font-display text-[1.3rem] font-semibold">
                  <Icon name="pin" size={19} className="text-brand-200" />
                  Based in {CONTACT.base}
                </p>
                <ul className="mt-5 grid gap-2.5 text-[0.94rem]">
                  <li>
                    <ContactRow
                      icon="phone"
                      label="Phone"
                      value={CONTACT.phone || PHONE_PLACEHOLDER}
                      href={phoneHref}
                      missing={!CONTACT.phone}
                    />
                  </li>
                  <li>
                    <ContactRow
                      icon="mail"
                      label="Email"
                      value={CONTACT.email || EMAIL_PLACEHOLDER}
                      href={emailHref}
                      missing={!CONTACT.email}
                    />
                  </li>
                  <li>
                    <ContactRow icon="chat" label="Message" value="Use the quote form — reply as soon as possible" />
                  </li>
                </ul>
                <p className="mt-5 rounded-2xl bg-brand-950/40 p-3.5 text-[0.8rem] leading-relaxed text-brand-100/80">
                  <span className="font-bold text-white">Demo note:</span> once the real number and email are added to
                  the site config, both buttons above become live tap-to-call and tap-to-email links.
                </p>
              </div>
            </Reveal>

            <Reveal delay={150}>
              <div className="rounded-[30px] border border-white/15 bg-white/8 p-6 text-white backdrop-blur-md">
                <p className="u-eyebrow text-brand-200">Postcodes covered</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {AREAS.map((a) => (
                    <button
                      key={a.code}
                      type="button"
                      onClick={() => set("postcode")(a.code)}
                      className={`rounded-full border px-3 py-1.5 text-[0.8rem] font-bold tracking-wide transition-all duration-300 ${
                        values.postcode.toUpperCase().startsWith(a.code)
                          ? "border-brand-200 bg-brand-200 text-brand-900"
                          : "border-white/20 bg-white/10 hover:-translate-y-0.5 hover:border-brand-200 hover:bg-brand-200 hover:text-brand-900"
                      }`}
                    >
                      {a.code}
                    </button>
                  ))}
                </div>
                <ul className="mt-5 grid gap-2 text-[0.9rem] text-brand-100/85">
                  {["Last-minute bookings may be available", "Natural, non-toxic products as standard", "Personalised quotes for every property"].map(
                    (t) => (
                      <li key={t} className="flex items-center gap-2">
                        <Icon name="check" size={13} strokeWidth={2.6} className="text-leaf-300" />
                        {t}
                      </li>
                    )
                  )}
                </ul>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------ bits ------------------------------ */
function Field({
  label,
  id,
  error,
  hint,
  required,
  children,
}: {
  label: string;
  id: string;
  error?: string;
  hint?: string;
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 flex items-baseline justify-between gap-3 text-[0.78rem] font-bold uppercase tracking-[0.12em] text-ink">
        <span>
          {label}
          {required && <span className="ml-1 text-brand-600">*</span>}
        </span>
        {hint && <span className="text-[0.68rem] font-semibold normal-case tracking-normal text-ink-mute">{hint}</span>}
      </label>
      {children}
      <p
        className={`overflow-hidden text-[0.78rem] font-semibold text-[#c2542f] transition-all duration-300 ${
          error ? "mt-1.5 max-h-8" : "max-h-0"
        }`}
        role={error ? "alert" : undefined}
      >
        {error}
      </p>
    </div>
  );
}

function ContactRow({
  icon,
  label,
  value,
  href,
  missing,
}: {
  icon: "phone" | "mail" | "chat";
  label: string;
  value: string;
  href?: string;
  missing?: boolean;
}) {
  const inner = (
    <>
      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white/12 text-brand-200 ring-1 ring-white/15">
        <Icon name={icon} size={17} />
      </span>
      <span className="min-w-0">
        <span className="block text-[0.66rem] font-bold uppercase tracking-[0.16em] text-brand-200/80">{label}</span>
        <span className={`block truncate text-[0.95rem] font-semibold ${missing ? "text-white/70" : ""}`}>{value}</span>
      </span>
    </>
  );

  if (href) {
    return (
      <a
        href={href}
        className="group flex items-center gap-3 rounded-2xl p-2 -m-2 transition-colors duration-300 hover:bg-white/10"
      >
        {inner}
        <Icon name="arrowRight" size={16} className="ml-auto shrink-0 opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:opacity-100" />
      </a>
    );
  }

  return (
    <span
      title="Placeholder — replace with Becky's real details in src/lib/data.ts"
      className="-m-2 flex items-center gap-3 rounded-2xl border border-dashed border-white/25 p-2"
    >
      {inner}
    </span>
  );
}


