import { useEffect, useState } from "react";
import { Icon } from "./Icons";
import { IconChip, SectionHead, Tick } from "./Bits";
import { EXTRA_SERVICES, SERVICES, type Service } from "../lib/data";
import { Reveal, scrollToId, useLockBody, useQuote } from "../lib/ui";

const FEATURED_META: Record<string, string> = {
  "house-cleaning": "One-off or regular visits",
  "deep-cleaning": "Top-to-bottom reset",
};

export default function Services() {
  const [openId, setOpenId] = useState<string | null>(null);
  const { requestQuote } = useQuote();
  const active = SERVICES.find((s) => s.id === openId) ?? null;
  useLockBody(Boolean(active));

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpenId(null);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const featured = SERVICES.filter((s) => s.featured);
  const rest = SERVICES.filter((s) => !s.featured);

  return (
    <section id="services" className="relative py-20 sm:py-28">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10"
        style={{
          backgroundImage:
            "radial-gradient(52% 40% at 100% 0%, rgba(67,186,176,0.10) 0%, rgba(67,186,176,0) 70%), radial-gradient(44% 36% at 0% 100%, rgba(168,217,174,0.14) 0%, rgba(168,217,174,0) 70%)",
        }}
      />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
          <SectionHead
            eyebrow="What Becky does"
            title={
              <>
                Cleaning services tailored <br className="hidden sm:block" /> to your home
              </>
            }
            lead="Choose a single reset or a regular routine. Every visit is worked around the rooms, the mess and the finish you actually want — and you can mix services together in one booking."
          />
          <Reveal delay={140}>
            <div className="flex flex-wrap items-center gap-3 lg:justify-end">
              <button type="button" onClick={() => requestQuote("Deep Cleaning")} className="btn btn-ink py-2.5! text-sm">
                Request a Cleaning Quote
                <Icon name="arrowRight" size={16} className="btn-arrow" />
              </button>
              <button type="button" onClick={() => scrollToId("pricing")} className="btn btn-ghost py-2.5! text-sm">
                See pricing
              </button>
            </div>
          </Reveal>
        </div>

        {/* two image-led feature cards */}
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {featured.map((s, i) => (
            <Reveal key={s.id} delay={i * 90}>
              <article className="card card-hover group flex h-full flex-col overflow-hidden">
                <div className="relative overflow-hidden">
                  <img
                    src={s.image}
                    alt={`${s.title} in a Bristol home — Becky's Cleaning Services`}
                    width={1000}
                    height={700}
                    loading="lazy"
                    decoding="async"
                    className="h-52 w-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.2,0.7,0.2,1)] group-hover:scale-[1.06] sm:h-60"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-950/55 via-brand-950/5 to-transparent" />
                  <span className="absolute left-4 top-4 inline-flex items-center gap-2 rounded-full bg-white/95 px-3 py-1.5 text-[0.68rem] font-bold uppercase tracking-[0.14em] text-brand-700 shadow-soft">
                    Most requested
                  </span>
                  <p className="absolute bottom-4 left-4 right-4 flex items-center justify-between gap-3 text-white">
                    <span className="font-display text-[1.55rem] font-semibold leading-tight">{s.title}</span>
                    <span className="shrink-0 rounded-full bg-white/15 px-3 py-1 text-[0.72rem] font-bold ring-1 ring-white/25 backdrop-blur">
                      {s.price}
                    </span>
                  </p>
                </div>
                <div className="flex flex-1 flex-col gap-4 p-6">
                  <div className="-mt-9 flex items-center gap-3">
                    <span className="grid h-[46px] w-[46px] place-items-center rounded-2xl bg-white text-brand-700 shadow-soft ring-1 ring-brand-100 transition-transform duration-500 group-hover:-rotate-6">
                      <Icon name={s.icon} size={22} />
                    </span>
                    <p className="text-[0.72rem] font-bold uppercase tracking-[0.16em] text-ink-mute">
                      {FEATURED_META[s.id]}
                    </p>
                  </div>
                  <p className="text-[0.98rem] leading-relaxed text-ink-soft">{s.blurb}</p>
                  <ul className="grid gap-2 sm:grid-cols-2">
                    {s.includes.slice(0, 4).map((inc) => (
                      <Tick key={inc}>{inc}</Tick>
                    ))}
                  </ul>
                  <button
                    type="button"
                    onClick={() => setOpenId(s.id)}
                    className="mt-auto inline-flex items-center gap-2 self-start rounded-full bg-brand-50 px-4 py-2 text-sm font-bold text-brand-700 ring-1 ring-brand-100 transition-all duration-300 hover:bg-brand-600 hover:text-white hover:ring-brand-600"
                  >
                    Learn More
                    <Icon name="chevron" size={15} />
                  </button>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        {/* four icon-led cards */}
        <div className="mt-5 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {rest.map((s, i) => (
            <Reveal key={s.id} delay={i * 80}>
              <article className="card card-hover group flex h-full flex-col p-6">
                <IconChip name={s.icon} className="h-12 w-12" />
                <h3 className="mt-5 text-[1.2rem] font-semibold leading-snug text-ink">{s.title}</h3>
                <p className="mt-2.5 text-[0.94rem] leading-relaxed text-ink-soft">{s.blurb}</p>
                <p className="mt-4 text-[0.78rem] font-bold uppercase tracking-[0.13em] text-leaf-600">{s.price}</p>
                <button
                  type="button"
                  onClick={() => setOpenId(s.id)}
                  className="mt-auto inline-flex items-center gap-1.5 pt-5 text-sm font-bold text-brand-700 transition-colors hover:text-brand-500"
                >
                  Learn More
                  <Icon name="arrowRight" size={15} className="transition-transform duration-300 group-hover:translate-x-1" />
                </button>
              </article>
            </Reveal>
          ))}
        </div>

        {/* extra services band */}
        <Reveal delay={80}>
          <div className="mt-5 overflow-hidden rounded-[28px] border border-brand-100 bg-gradient-to-br from-brand-50 via-white to-leaf-100/70 p-5 sm:p-7">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
              <p className="u-eyebrow shrink-0 text-brand-700 sm:w-40">Also available</p>
              <ul className="grid flex-1 gap-3 sm:grid-cols-2">
                {EXTRA_SERVICES.map((s) => (
                  <li key={s.id}>
                    <div className="group flex h-full items-start gap-3.5 rounded-2xl bg-white/85 p-4 ring-1 ring-brand-100 transition-all duration-300 hover:ring-brand-300">
                      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-600/10 text-brand-700 transition-transform duration-500 group-hover:rotate-6">
                        <Icon name={s.icon} size={20} />
                      </span>
                      <div>
                        <p className="flex flex-wrap items-center gap-2 font-display text-[1.05rem] font-semibold text-ink">
                          {s.title}
                          <span className="rounded-full bg-leaf-100 px-2 py-0.5 text-[0.68rem] font-bold uppercase tracking-wide text-leaf-600">
                            {s.price}
                          </span>
                        </p>
                        <p className="mt-1 text-[0.9rem] leading-snug text-ink-soft">{s.blurb}</p>
                        <button
                          type="button"
                          onClick={() => requestQuote(s.title)}
                          className="mt-2 inline-flex items-center gap-1.5 text-[0.85rem] font-bold text-brand-700 hover:text-brand-500"
                        >
                          Ask about this <Icon name="arrowRight" size={14} className="btn-arrow" />
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Reveal>
      </div>

      {/* ── service detail modal ── */}
      {active && <ServiceModal service={active} onClose={() => setOpenId(null)} onQuote={() => { setOpenId(null); requestQuote(active.title); }} />}
    </section>
  );
}

function ServiceModal({
  service,
  onClose,
  onQuote,
}: {
  service: Service;
  onClose: () => void;
  onQuote: () => void;
}) {
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const t = window.setTimeout(() => setShown(true), 10);
    return () => window.clearTimeout(t);
  }, []);

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center p-0 sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label={`${service.title} details`}>
      <button
        type="button"
        aria-label="Close details"
        onClick={onClose}
        className={`absolute inset-0 bg-brand-950/45 backdrop-blur-sm transition-opacity duration-300 ${shown ? "opacity-100" : "opacity-0"}`}
      />
      <div
        className={`relative max-h-[88vh] w-full max-w-2xl overflow-y-auto overscroll-contain rounded-t-[32px] bg-white shadow-lift transition-all duration-400 ease-[cubic-bezier(0.2,0.7,0.2,1)] sm:rounded-[32px] ${
          shown ? "translate-y-0 opacity-100 sm:scale-100" : "translate-y-8 opacity-0 sm:scale-[0.97]"
        }`}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="absolute right-4 top-4 z-10 grid h-10 w-10 place-items-center rounded-full bg-white/90 text-ink shadow-soft ring-1 ring-brand-100 transition-colors hover:bg-brand-50"
        >
          <Icon name="close" size={18} />
        </button>

        <div className="relative">
          <img src={service.image} alt={`${service.title} carried out by Becky's Cleaning Services`} width={1000} height={700} className="h-44 w-full object-cover sm:h-56" />
          <div className="absolute inset-0 bg-gradient-to-t from-brand-950/70 to-transparent" />
          <div className="absolute bottom-4 left-5 right-5">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-[0.68rem] font-bold uppercase tracking-[0.16em] text-white ring-1 ring-white/25 backdrop-blur">
              {service.price}
            </span>
            <h3 className="mt-2.5 font-display text-[1.9rem] font-semibold leading-tight text-white">{service.title}</h3>
          </div>
        </div>

        <div className="p-6 sm:p-8">
          <p className="text-[1rem] leading-relaxed text-ink-soft">{service.intro}</p>
          <p className="u-eyebrow mt-7 text-brand-700">What&rsquo;s included</p>
          <ul className="mt-3.5 grid gap-2.5 sm:grid-cols-2">
            {service.includes.map((inc) => (
              <Tick key={inc}>{inc}</Tick>
            ))}
          </ul>
          <div className="mt-7 flex flex-col gap-3 rounded-2xl bg-shell p-4 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-[0.92rem] leading-snug text-ink-soft">
              Booking this with another service? Send the details and Becky will price it as one visit.
            </p>
            <div className="flex shrink-0 gap-2">
              <button type="button" onClick={onQuote} className="btn btn-primary sheen py-2.5! text-sm">
                Get a Free Quote
              </button>
              <button type="button" onClick={() => { onClose(); scrollToId("pricing"); }} className="btn btn-ghost py-2.5! text-sm">
                Pricing
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
