import { Icon } from "./Icons";
import { SectionHead, Tick } from "./Bits";
import { px } from "../lib/data";
import { Reveal, useQuote } from "../lib/ui";

const FACTS = [
  { n: "2011", l: "Posting in Bristol since" },
  { n: "6", l: "Bristol postcode areas covered" },
  { n: "8", l: "Home cleaning services offered" },
];

export default function About() {
  const { requestQuote } = useQuote();

  return (
    <section id="about" className="relative overflow-hidden py-20 sm:py-28">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 bg-shell" />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-40"
        style={{ backgroundImage: "linear-gradient(to bottom, rgba(255,255,255,0.9), rgba(255,255,255,0))" }}
      />

      <div className="mx-auto grid max-w-7xl gap-12 px-4 sm:px-6 lg:grid-cols-[0.95fr_1.05fr] lg:gap-16">
        {/* imagery */}
        <div className="relative">
          <Reveal>
            <div className="relative overflow-hidden rounded-[36px] rounded-bl-[110px] border border-white shadow-lift">
              <img
                src={px(7345413, 880, 1120)}
                srcSet={`${px(7345413, 520, 662)} 520w, ${px(7345413, 880, 1120)} 880w`}
                sizes="(min-width: 1024px) 40vw, 90vw"
                width={880}
                height={1120}
                alt="Becky, an experienced cleaner and housekeeper, preparing to clean a bright Bristol home"
                loading="lazy"
                decoding="async"
                className="h-[clamp(320px,58vw,540px)] w-full object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-950/40 via-transparent to-transparent" />
            </div>
          </Reveal>

          <Reveal delay={120} className="absolute -bottom-8 -right-2 w-[72%] max-w-[300px] sm:-right-6">
            <div className="card overflow-hidden rounded-3xl! p-3">
              <img
                src={px(9462326, 700, 460)}
                width={700}
                height={460}
                alt="A bed being made and a bedroom tidied during a housekeeping visit"
                loading="lazy"
                decoding="async"
                className="h-32 w-full rounded-2xl object-cover"
              />
              <div className="flex items-start gap-2.5 px-1.5 pb-1 pt-3">
                <Icon name="houseHeart" size={18} className="mt-0.5 shrink-0 text-brand-600" />
                <p className="text-[0.85rem] font-semibold leading-snug text-ink">
                  Housekeeping too — beds, laundry folded away, towels fresh, everything back where it belongs.
                </p>
              </div>
            </div>
          </Reveal>
        </div>

        {/* copy */}
        <div className="pt-4 lg:pt-10">
          <SectionHead
            eyebrow="Meet Becky"
            title={
              <>
                About Becky&rsquo;s <br className="hidden sm:block" />
                Cleaning Services
              </>
            }
          />

          <div className="mt-6 grid gap-5 text-[1.02rem] leading-relaxed text-ink-soft">
            <Reveal delay={60}>
              <p>
                Welcome to Becky&rsquo;s Cleaning Services. Based in Bristol, Becky provides professional cleaning
                and housekeeping services with a strong focus on quality, reliability and customer satisfaction.
              </p>
            </Reveal>
            <Reveal delay={110}>
              <p>
                Whether you need a one-off clean, regular home cleaning, a deep clean or end of tenancy cleaning, the
                service can be tailored around your individual needs.
              </p>
            </Reveal>
            <Reveal delay={160}>
              <p>
                Becky also focuses on using all-natural, non-toxic cleaning products wherever suitable, helping create
                a clean and comfortable environment for you and your family.
              </p>
            </Reveal>
          </div>

          <Reveal delay={210}>
            <ul className="mt-8 grid gap-2.5 sm:grid-cols-2">
              {[
                "Friendly, consistent, one-to-one service",
                "No agency staff — Becky cleans your home",
                "Equipment and products brought to every visit",
                "Honest advice on what a clean will need",
              ].map((t) => (
                <Tick key={t}>{t}</Tick>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={260}>
            <dl className="mt-9 grid gap-px overflow-hidden rounded-3xl bg-brand-900/8 sm:grid-cols-3">
              {FACTS.map((f) => (
                <div key={f.l} className="bg-white px-5 py-6 transition-colors duration-300 hover:bg-brand-50">
                  <dt className="sr-only">{f.l}</dt>
                  <dd className="font-display text-[2rem] font-semibold leading-none text-brand-700">{f.n}</dd>
                  <dd className="mt-2 text-[0.78rem] font-bold uppercase tracking-[0.12em] text-ink-mute">{f.l}</dd>
                </div>
              ))}
            </dl>
          </Reveal>

          <Reveal delay={320}>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button type="button" onClick={() => requestQuote()} className="btn btn-primary sheen">
                Contact Becky
                <Icon name="arrowRight" size={16} className="btn-arrow" />
              </button>
              <p className="text-[0.86rem] font-semibold text-ink-soft">
                Prefer to chat first? Ask about a call-back at a time that suits you.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
