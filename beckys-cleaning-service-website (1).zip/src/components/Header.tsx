import { useEffect, useState } from "react";
import { Icon } from "./Icons";
import { Logo } from "./Bits";
import { BUSINESS, CONTACT, NAV, PHONE_PLACEHOLDER, EMAIL_PLACEHOLDER, phoneHref, emailHref } from "../lib/data";
import { scrollToId, useLockBody, useQuote, useScrollSpy, useScrolled } from "../lib/ui";

const NAV_IDS = NAV.map((n) => n.id);

export default function Header() {
  const scrolled = useScrolled(24);
  const active = useScrollSpy(NAV_IDS);
  const [open, setOpen] = useState(false);
  const [progress, setProgress] = useState(0);
  const { requestQuote } = useQuote();
  useLockBody(open);

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(h > 0 ? Math.min(1, window.scrollY / h) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const go = (id: string) => {
    setOpen(false);
    window.setTimeout(() => scrollToId(id), 60);
  };

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50">
        {/* announcement strip */}
        <div
          className={`overflow-hidden bg-brand-900 text-brand-100 transition-all duration-500 ${
            scrolled ? "max-h-0 opacity-0" : "max-h-12 opacity-100"
          }`}
        >
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-2 text-[0.72rem] font-semibold tracking-wide sm:px-6 sm:text-xs">
            <p className="flex items-center gap-2">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-leaf-300" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-leaf-300" />
              </span>
              <span className="hidden sm:inline">Serving Bristol since {BUSINESS.since} · one-off, weekly, fortnightly &amp; monthly cleans</span>
              <span className="sm:hidden">Serving Bristol since {BUSINESS.since}</span>
            </p>
            <p className="hidden items-center gap-5 md:flex">
              <span className="inline-flex items-center gap-1.5">
                <Icon name="pin" size={13} className="text-brand-200" /> {BUSINESS.location}
              </span>
              <span className="inline-flex items-center gap-1.5 opacity-80">
                <Icon name="phone" size={13} className="text-brand-200" /> {CONTACT.phone || PHONE_PLACEHOLDER}
              </span>
            </p>
          </div>
        </div>

        {/* main bar */}
        <div
          className={`relative transition-all duration-500 ${
            scrolled ? "bg-white/88 shadow-[0_10px_30px_-24px_rgba(13,43,41,0.55)] backdrop-blur-xl" : "bg-white/0"
          }`}
        >
          <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                go("home");
              }}
              aria-label={`${BUSINESS.name} — home`}
              className="rounded-2xl transition-transform duration-300 hover:scale-[1.02]"
            >
              <Logo />
            </a>

            <nav aria-label="Primary" className="hidden items-center gap-7 lg:flex">
              {NAV.map((item) => (
                <a
                  key={item.id}
                  href={`#${item.id}`}
                  data-active={active === item.id ? "true" : "false"}
                  onClick={(e) => {
                    e.preventDefault();
                    go(item.id);
                  }}
                  className={`link-underline text-[0.9rem] font-semibold transition-colors duration-300 ${
                    active === item.id ? "text-brand-700" : "text-ink/75 hover:text-brand-700"
                  }`}
                >
                  {item.label}
                </a>
              ))}
            </nav>

            <div className="flex items-center gap-2">
              {phoneHref ? (
                <a
                  href={phoneHref}
                  className="btn btn-ghost hidden px-4! py-0! text-sm! md:inline-flex"
                  aria-label={`Call Becky on ${CONTACT.phone}`}
                >
                  <Icon name="phone" size={16} className="text-brand-600" />
                  {CONTACT.phone}
                </a>
              ) : (
                <span
                  title="Add Becky's real phone number in src/lib/data.ts to make this button live"
                  className="hidden items-center gap-2 rounded-full border border-dashed border-brand-200 px-4 py-2 text-sm font-semibold text-ink-mute md:inline-flex"
                >
                  <Icon name="phone" size={16} className="text-brand-400" />
                  {PHONE_PLACEHOLDER}
                </span>
              )}

              <button type="button" onClick={() => requestQuote()} className="btn btn-primary sheen hidden py-2.5! text-sm sm:inline-flex">
                Get a Free Quote
                <Icon name="arrowRight" size={16} className="btn-arrow" />
              </button>

              <button
                type="button"
                onClick={() => requestQuote()}
                aria-label="Get a free quote"
                className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-b from-brand-500 to-brand-700 text-white shadow-glow transition-transform duration-300 active:scale-95 sm:hidden"
              >
                <Icon name="sparkle" size={19} strokeWidth={1.7} />
              </button>

              <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                aria-expanded={open}
                aria-controls="mobile-menu"
                aria-label={open ? "Close menu" : "Open menu"}
                className="grid h-11 w-11 place-items-center rounded-2xl border border-brand-100 bg-white text-ink shadow-soft transition-colors hover:bg-brand-50 lg:hidden"
              >
                <Icon name={open ? "close" : "menu"} size={20} />
              </button>
            </div>
          </div>

          {/* scroll progress */}
          <div className="absolute inset-x-0 bottom-0 h-px bg-brand-900/5">
            <div
              className="h-full origin-left bg-gradient-to-r from-brand-500 via-brand-400 to-leaf-500 transition-[transform] duration-150"
              style={{ transform: `scaleX(${progress})` }}
            />
          </div>
        </div>
      </header>

      {/* mobile sheet */}
      <div
        id="mobile-menu"
        className={`fixed inset-0 z-40 lg:hidden ${open ? "" : "pointer-events-none"}`}
        aria-hidden={!open}
      >
        <button
          type="button"
          tabIndex={open ? 0 : -1}
          aria-label="Close menu"
          onClick={() => setOpen(false)}
          className={`absolute inset-0 bg-ink/35 backdrop-blur-[2px] transition-opacity duration-400 ${
            open ? "opacity-100" : "opacity-0"
          }`}
        />
        <nav
          className={`absolute inset-x-0 top-0 max-h-[92vh] origin-top overflow-y-auto overscroll-contain rounded-b-[34px] bg-white px-5 pb-8 pt-24 shadow-lift transition-all duration-400 ease-[cubic-bezier(0.2,0.7,0.2,1)] ${
            open ? "translate-y-0 opacity-100" : "-translate-y-6 opacity-0"
          }`}
        >
          <ul className="divide-y divide-brand-900/5">
            {NAV.map((item, i) => (
              <li key={item.id}>
                <a
                  href={`#${item.id}`}
                  tabIndex={open ? 0 : -1}
                  onClick={(e) => {
                    e.preventDefault();
                    go(item.id);
                  }}
                  className="flex items-center justify-between gap-3 py-4 text-ink"
                >
                  <span className="flex items-baseline gap-3">
                    <span className="font-sans text-[0.65rem] font-bold tracking-[0.2em] text-brand-400">
                      0{i + 1}
                    </span>
                    <span
                      className={`font-display text-[1.45rem] font-semibold ${
                        active === item.id ? "text-brand-700" : ""
                      }`}
                    >
                      {item.label}
                    </span>
                  </span>
                  <Icon name="arrowRight" size={18} className="text-brand-500" />
                </a>
              </li>
            ))}
          </ul>

          <div className="mt-6 grid gap-2.5">
            <button
              type="button"
              tabIndex={open ? 0 : -1}
              onClick={() => {
                setOpen(false);
                requestQuote();
              }}
              className="btn btn-primary sheen w-full"
            >
              Get a Free Quote
              <Icon name="arrowRight" size={17} className="btn-arrow" />
            </button>
            <div className="grid grid-cols-2 gap-2.5">
              {phoneHref ? (
                <a href={phoneHref} tabIndex={open ? 0 : -1} className="btn btn-ghost px-3! text-sm">
                  <Icon name="phone" size={15} className="text-brand-600" /> Call
                </a>
              ) : (
                <span className="btn btn-ghost w-full cursor-help px-3! text-center text-[0.72rem] leading-tight text-ink-mute">
                  {PHONE_PLACEHOLDER}
                </span>
              )}
              {emailHref ? (
                <a href={emailHref} tabIndex={open ? 0 : -1} className="btn btn-ghost px-3! text-sm">
                  <Icon name="mail" size={15} className="text-brand-600" /> Email
                </a>
              ) : (
                <span className="btn btn-ghost w-full cursor-help px-3! text-center text-[0.72rem] leading-tight text-ink-mute">
                  {EMAIL_PLACEHOLDER}
                </span>
              )}
            </div>
            <p className="mt-1 text-center text-xs font-semibold uppercase tracking-[0.16em] text-ink-mute">
              BS6 · BS7 · BS9 · BS10 · BS11 · BS34
            </p>
          </div>
        </nav>
      </div>
    </>
  );
}
