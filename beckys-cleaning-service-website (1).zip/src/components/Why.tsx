import { Icon } from "./Icons";
import { Bubbles } from "./Bits";
import { FEATURES } from "../lib/data";
import { Reveal, useQuote } from "../lib/ui";

export default function Why() {
  const { requestQuote } = useQuote();

  return (
    <section id="why" className="relative py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <Reveal>
          <div className="relative overflow-hidden rounded-[40px] bg-brand-950 px-5 py-12 text-white shadow-lift sm:px-10 sm:py-16">
            {/* texture + glow */}
            <div
              aria-hidden="true"
              className="paper pointer-events-none absolute inset-0 opacity-[0.13]"
              style={{ filter: "invert(1)" }}
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -right-24 -top-28 h-[420px] w-[420px] rounded-full opacity-70"
              style={{ background: "radial-gradient(circle, rgba(67,186,176,0.45) 0%, rgba(67,186,176,0) 68%)" }}
            />
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -bottom-32 left-1/4 h-[360px] w-[360px] rounded-full opacity-60"
              style={{ background: "radial-gradient(circle, rgba(79,169,106,0.42) 0%, rgba(79,169,106,0) 70%)" }}
            />
            <Bubbles count={6} className="opacity-[0.12]" />

            <div className="relative grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:gap-14">
              <div>
                <span className="u-eyebrow inline-flex items-center gap-2 text-brand-200">
                  <span className="h-px w-7 bg-brand-200/60" />
                  Why homeowners stay
                </span>
                <h2 className="mt-4 text-[clamp(1.9rem,5vw,3rem)] font-semibold leading-[1.04]">
                  Six reasons Bristol households keep the number saved
                </h2>
                <p className="mt-5 max-w-md text-[1rem] leading-relaxed text-brand-100/80">
                  Experience, flexibility and a genuinely thorough finish — with products you are happy to have around
                  children and pets. No call centre, no strangers with a checklist.
                </p>

                <div className="mt-8 flex flex-wrap gap-3">
                  <button type="button" onClick={() => requestQuote()} className="btn sheen bg-white text-brand-800 hover:-translate-y-0.5 hover:shadow-glow">
                    Get a Free Quote
                    <Icon name="arrowRight" size={16} className="btn-arrow" />
                  </button>
                  <button
                    type="button"
                    onClick={() => requestQuote("House Cleaning")}
                    className="btn border border-white/25 text-white transition-colors duration-300 hover:bg-white/10"
                  >
                    Book a service
                  </button>
                </div>
              </div>

              <ul className="grid gap-px overflow-hidden rounded-[28px] bg-white/10 sm:grid-cols-2">
                {FEATURES.map((f, i) => (
                  <Reveal as="li" key={f.title} delay={i * 70}>
                    <div className="group h-full bg-brand-950/80 p-5 transition-colors duration-500 hover:bg-brand-900 sm:p-6">
                      <div className="flex items-center justify-between">
                        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-white/10 text-brand-200 ring-1 ring-white/15 transition-all duration-500 group-hover:bg-leaf-500 group-hover:text-white group-hover:ring-leaf-500">
                          <Icon name={f.icon} size={21} />
                        </span>
                        <span className="font-display text-[0.95rem] font-semibold text-white/25">
                          0{i + 1}
                        </span>
                      </div>
                      <h3 className="mt-4 text-[1.12rem] font-semibold leading-snug">{f.title}</h3>
                      <p className="mt-2 text-[0.92rem] leading-relaxed text-brand-100/70">{f.text}</p>
                    </div>
                  </Reveal>
                ))}
              </ul>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
