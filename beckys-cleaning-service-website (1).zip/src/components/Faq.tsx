import { useState } from "react";
import { Icon } from "./Icons";
import { SectionHead } from "./Bits";
import { FAQS } from "../lib/data";
import { Reveal, useQuote } from "../lib/ui";

export default function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  const { requestQuote } = useQuote();

  return (
    <section id="faq" className="relative py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-[0.82fr_1.18fr] lg:gap-16">
        <div>
          <SectionHead
            eyebrow="Good to know"
            title={
              <>
                Questions, <br className="hidden sm:block" />
                answered
              </>
            }
            lead="The things customers ask most before booking a clean."
          />
          <Reveal delay={160}>
            <div className="mt-8 rounded-[28px] border border-brand-100 bg-brand-50/70 p-6">
              <p className="font-display text-[1.25rem] font-semibold leading-snug text-ink">
                Something not covered here?
              </p>
              <p className="mt-2 text-[0.94rem] leading-relaxed text-ink-soft">
                Ask away — carpet numbers, garden sheds, a loft that needs clearing first. If it can be cleaned,
                it can be quoted.
              </p>
              <button type="button" onClick={() => requestQuote()} className="btn btn-primary sheen mt-5 py-2.5! text-sm">
                Ask a question
                <Icon name="arrowRight" size={15} className="btn-arrow" />
              </button>
            </div>
          </Reveal>
        </div>

        <ul className="grid gap-3">
          {FAQS.map((f, i) => {
            const isOpen = open === i;
            return (
              <Reveal as="li" key={f.q} delay={i * 55}>
                <div
                  className={`card overflow-hidden rounded-[22px]! transition-all duration-400 ${
                    isOpen ? "border-brand-300! shadow-soft!" : "hover:border-brand-200!"
                  }`}
                >
                  <h3>
                    <button
                      type="button"
                      onClick={() => setOpen(isOpen ? null : i)}
                      aria-expanded={isOpen}
                      className="flex w-full items-center justify-between gap-5 px-5 py-5 text-left sm:px-6"
                    >
                      <span className="flex items-start gap-4">
                        <span className={`mt-0.5 text-[0.72rem] font-bold tracking-[0.14em] ${isOpen ? "text-brand-600" : "text-ink-mute"}`}>
                          Q{i + 1}
                        </span>
                        <span className={`text-[1.04rem] font-semibold leading-snug transition-colors duration-300 ${isOpen ? "text-brand-800" : "text-ink"}`}>
                          {f.q}
                        </span>
                      </span>
                      <span
                        className={`grid h-9 w-9 shrink-0 place-items-center rounded-full transition-all duration-400 ${
                          isOpen ? "rotate-180 bg-brand-600 text-white" : "bg-brand-50 text-brand-700"
                        }`}
                      >
                        <Icon name="chevron" size={17} strokeWidth={2} />
                      </span>
                    </button>
                  </h3>
                  <div
                    className="grid transition-[grid-template-rows] duration-400 ease-[cubic-bezier(0.2,0.7,0.2,1)]"
                    style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                  >
                    <div className="overflow-hidden">
                      <p className="px-5 pb-5 text-[0.97rem] leading-relaxed text-ink-soft sm:px-6 sm:pl-[4.4rem] sm:pr-16">
                        {f.a}
                      </p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </ul>
      </div>
    </section>
  );
}
