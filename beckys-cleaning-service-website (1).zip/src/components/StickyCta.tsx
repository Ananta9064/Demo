import { useEffect, useState } from "react";
import { Icon } from "./Icons";
import { scrollToId, useQuote } from "../lib/ui";

/** Mobile-only sticky action bar — appears after the hero, hides over the contact form. */
export default function StickyCta() {
  const { requestQuote } = useQuote();
  const [show, setShow] = useState(false);

  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 520);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    let hideBar = false;
    const contact = document.getElementById("contact");
    const io =
      contact && typeof IntersectionObserver !== "undefined"
        ? new IntersectionObserver(
            (entries) => {
              hideBar = entries.some((e) => e.isIntersecting);
              if (hideBar) setShow(false);
            },
            { threshold: 0.06 }
          )
        : null;
    if (contact && io) io.observe(contact);

    return () => {
      window.removeEventListener("scroll", onScroll);
      io?.disconnect();
    };
  }, []);

  return (
    <div
      className={`fixed inset-x-0 bottom-0 z-40 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] transition-all duration-500 ease-[cubic-bezier(0.2,0.7,0.2,1)] lg:hidden ${
        show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-24 opacity-0"
      }`}
    >
      <div className="mx-auto flex max-w-md items-center gap-2 rounded-full border border-brand-100 bg-white/95 p-1.5 shadow-lift backdrop-blur-xl">
        <button
          type="button"
          onClick={() => requestQuote()}
          className="btn btn-primary flex-1 py-3! text-[0.92rem]"
        >
          <Icon name="sparkle" size={16} />
          Get a Free Quote
        </button>
        <button
          type="button"
          onClick={() => scrollToId("services")}
          aria-label="View services"
          className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-shell-deep text-brand-700 transition-colors hover:bg-brand-50"
        >
          <Icon name="broom" size={18} />
        </button>
      </div>
    </div>
  );
}
