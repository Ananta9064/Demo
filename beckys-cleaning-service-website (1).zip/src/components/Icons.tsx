import type { ReactElement, SVGProps } from "react";

export type IconName =
  | "sparkle"
  | "brush"
  | "oven"
  | "key"
  | "calendarRepeat"
  | "shieldLeaf"
  | "broom"
  | "houseHeart"
  | "badgeCheck"
  | "leaf"
  | "pin"
  | "tag"
  | "check"
  | "arrowRight"
  | "phone"
  | "mail"
  | "clock"
  | "droplet"
  | "quote"
  | "chevron"
  | "menu"
  | "close"
  | "chat"
  | "fileCheck"
  | "spray";

const paths: Record<IconName, ReactElement> = {
  sparkle: (
    <>
      <path d="M12 3.2l1.9 4.6 4.6 1.9-4.6 1.9L12 16.2l-1.9-4.6-4.6-1.9 4.6-1.9z" />
      <path d="M18.4 15.6l.8 1.9 1.9.8-1.9.8-.8 1.9-.8-1.9-1.9-.8 1.9-.8z" />
      <path d="M5.4 15.4l.6 1.4 1.4.6-1.4.6-.6 1.4-.6-1.4-1.4-.6 1.4-.6z" />
    </>
  ),
  brush: (
    <>
      <path d="M4.6 12.4l5.2-5.2 4.1 4.1-5.2 5.2z" />
      <path d="M13.9 6.4l1.7-1.9a2.4 2.4 0 013.4 3.4l-1.9 1.7" />
      <path d="M4.6 12.4L3 18.2a1.4 1.4 0 001.7 1.7l5.8-1.6" />
      <path d="M7.6 15.6l-1.9 1.4" />
    </>
  ),
  oven: (
    <>
      <rect x="3.6" y="4" width="16.8" height="16" rx="2.6" />
      <path d="M3.6 8.6h16.8" />
      <path d="M6.6 6.3h.01M9.4 6.3h.01" />
      <rect x="6.6" y="11.2" width="10.8" height="6" rx="1.6" />
      <path d="M8.8 13.4h6.4" />
    </>
  ),
  key: (
    <>
      <circle cx="8" cy="8.4" r="3.4" />
      <path d="M10.5 10.8l6.3 6.3M14.6 14.9l1.7-1.7M16.8 17.1l1.7-1.7" />
      <path d="M4.4 20.4h9.4" />
    </>
  ),
  calendarRepeat: (
    <>
      <rect x="3.4" y="5.2" width="17.2" height="15.4" rx="2.6" />
      <path d="M3.4 9.6h17.2M8 3.4v3.4M16 3.4v3.4" />
      <path d="M9 14.4h5.4a1.8 1.8 0 010 3.6H11" />
      <path d="M12.3 16.4L10.6 18l1.7 1.6" />
    </>
  ),
  shieldLeaf: (
    <>
      <path d="M12 3.4l6.8 2.3v6c0 4.2-2.8 7.1-6.8 8.9-4-1.8-6.8-4.7-6.8-8.9v-6z" />
      <path d="M12 15.6c2.4 0 3.6-1.6 3.6-3.9-2.6-.5-4.6.7-5.2 2.5" />
      <path d="M9 16.6c.4-1.6 1.5-2.6 3-3" />
    </>
  ),
  broom: (
    <>
      <path d="M14.6 4.6l4.8 4.8" />
      <path d="M17 7l-7.4 7.4" />
      <path d="M9.6 14.4l-3 3a3.4 3.4 0 004.8 4.8l3-3" />
      <path d="M6.6 17.4l4.8 4.8" />
      <path d="M4.4 21.2l1.4-1.4M8.6 22l1.2-1.2" />
    </>
  ),
  houseHeart: (
    <>
      <path d="M4 10.6L12 4l8 6.6V20a1.4 1.4 0 01-1.4 1.4H5.4A1.4 1.4 0 014 20z" />
      <path d="M12 17.6c-2-1.3-3-2.4-3-3.7a1.6 1.6 0 013-.8 1.6 1.6 0 013 .8c0 1.3-1 2.4-3 3.7z" />
    </>
  ),
  badgeCheck: (
    <>
      <path d="M12 3.2l2.3 1.7 2.8-.2.9 2.7 2.3 1.7-1 2.7 1 2.7-2.3 1.7-.9 2.7-2.8-.2L12 20.8l-2.3-1.7-2.8.2-.9-2.7L3.7 15l1-2.7-1-2.7 2.3-1.7.9-2.7 2.8.2z" />
      <path d="M9 12l2.2 2.2L15.4 10" />
    </>
  ),
  leaf: (
    <>
      <path d="M5 19c-1.6-6 2.4-12.4 14-14 1.4 9.6-4.4 14.6-11 13.6" />
      <path d="M5.4 18.6C8 15 11.4 12.6 15.6 11.2" />
    </>
  ),
  pin: (
    <>
      <path d="M12 21s6.6-6 6.6-10.6A6.6 6.6 0 005.4 10.4C5.4 15 12 21 12 21z" />
      <circle cx="12" cy="10.2" r="2.4" />
    </>
  ),
  tag: (
    <>
      <path d="M11.4 3.6H19a1.4 1.4 0 011.4 1.4v7.6a1.4 1.4 0 01-.4 1l-7.6 7.6a1.4 1.4 0 01-2 0l-7-7a1.4 1.4 0 010-2l7.1-7.2a1.4 1.4 0 01.9-1.4z" />
      <circle cx="16.2" cy="7.8" r="1.5" />
    </>
  ),
  check: <path d="M4.8 12.6l4.4 4.4 10-10" />,
  arrowRight: (
    <>
      <path d="M4.5 12h14" />
      <path d="M13.4 6.6L18.8 12l-5.4 5.4" />
    </>
  ),
  phone: (
    <>
      <path d="M7 3.6h2.2l1.6 3.8-2 1.4a9.4 9.4 0 004.6 4.6l1.4-2 3.8 1.6V17a3.4 3.4 0 01-3.4 3.4C10 20.4 3.6 14 3.6 7A3.4 3.4 0 017 3.6z" />
    </>
  ),
  mail: (
    <>
      <rect x="3" y="5.2" width="18" height="13.6" rx="2.4" />
      <path d="M4.2 7.4l7 5a1.6 1.6 0 002 0l7-5" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.4" />
      <path d="M12 7.4V12l3.2 2" />
    </>
  ),
  droplet: <path d="M12 3.4c3.6 4 5.6 6.4 5.6 9a5.6 5.6 0 11-11.2 0c0-2.6 2-5 5.6-9z" />,
  quote: (
    <>
      <path d="M9.4 6.4C6.2 7.6 4.4 10 4.4 13.2c0 2.6 1.4 4.4 3.6 4.4 1.8 0 3.2-1.2 3.2-3s-1.2-3-2.8-3c-.4 0-.7 0-1 .2.3-1.4 1.4-2.6 3-3.4z" />
      <path d="M18.6 6.4c-3.2 1.2-5 3.6-5 6.8 0 2.6 1.4 4.4 3.6 4.4 1.8 0 3.2-1.2 3.2-3s-1.2-3-2.8-3c-.4 0-.7 0-1 .2.3-1.4 1.4-2.6 3-3.4z" />
    </>
  ),
  chevron: <path d="M6 9.6l6 5.4 6-5.4" />,
  menu: <path d="M4 7h16M4 12h16M4 17h10" />,
  close: <path d="M6 6l12 12M18 6L6 18" />,
  chat: (
    <>
      <path d="M20.4 12.4c0 3.8-3.8 6.8-8.4 6.8-1 0-2-.2-2.9-.5L4 20.4l1.6-3.7a6.3 6.3 0 01-2-4.3c0-3.8 3.8-6.8 8.4-6.8s8.4 3 8.4 6.8z" />
      <path d="M8.6 12h.01M12 12h.01M15.4 12h.01" />
    </>
  ),
  fileCheck: (
    <>
      <path d="M14 3.6H7.4A2 2 0 005.4 5.6v12.8a2 2 0 002 2h9.2a2 2 0 002-2V8.6z" />
      <path d="M13.8 3.6v5h5.8" />
      <path d="M9 14.4l2 2 4-4.2" />
    </>
  ),
  spray: (
    <>
      <path d="M9.6 8.4h4.2a2.4 2.4 0 012.4 2.4v8a1.6 1.6 0 01-1.6 1.6h-5.8a1.6 1.6 0 01-1.6-1.6v-8a2.4 2.4 0 012.4-2.4z" />
      <path d="M9.6 8.4V5.6h3.2M12.8 5.6h3.4" />
      <path d="M18.6 4.4h.01M20.4 6.6h.01M18.2 8.4h.01" />
      <path d="M9.8 13h4.6" />
    </>
  ),
};

interface IconProps extends SVGProps<SVGSVGElement> {
  name: IconName;
  size?: number;
}

export function Icon({ name, size = 24, strokeWidth = 1.6, className, ...rest }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      className={className}
      {...rest}
    >
      {paths[name]}
    </svg>
  );
}

export function Spinner({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" width={20} height={20} fill="none" className={`animate-spin ${className}`} aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity="0.25" strokeWidth="2.4" />
      <path d="M21 12a9 9 0 00-9-9" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}
