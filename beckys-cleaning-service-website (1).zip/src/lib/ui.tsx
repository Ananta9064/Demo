import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";

/* ------------------------------------------------------------------ *
 *  Reveal — fade + rise on scroll (once, cheap, reduced-motion safe)
 * ------------------------------------------------------------------ */
export function Reveal({
  children,
  className = "",
  delay = 0,
  as = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "li" | "span" | "article" | "section";
}) {
  const ref = useRef<HTMLElement | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setInView(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setInView(true);
            io.unobserve(e.target);
          }
        });
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.12 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const Tag = as as "div";
  return (
    <Tag
      ref={ref as React.RefObject<HTMLDivElement>}
      data-in={inView ? "true" : "false"}
      className={`reveal ${className}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

/* ------------------------------------------------------------------ *
 *  Scroll spy for the nav
 * ------------------------------------------------------------------ */
export function useScrollSpy(ids: string[]) {
  const [active, setActive] = useState(ids[0] ?? "");
  const key = ids.join(",");

  useEffect(() => {
    if (typeof IntersectionObserver === "undefined") return;
    const visible = new Set<string>();
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) visible.add(e.target.id);
          else visible.delete(e.target.id);
        });
        const found = ids.filter((id) => visible.has(id)).sort(
          (a, b) => (document.getElementById(a)?.offsetTop ?? 0) - (document.getElementById(b)?.offsetTop ?? 0)
        )[0];
        if (found) setActive(found);
      },
      { rootMargin: "-42% 0px -42% 0px", threshold: [0, 0.2, 0.6] }
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) io.observe(el);
    });
    const onScroll = () => {
      if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 6) {
        setActive(ids[ids.length - 1]);
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      io.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  return active;
}

/* ------------------------------------------------------------------ *
 *  Smooth scroll to a section
 * ------------------------------------------------------------------ */
export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const top = el.getBoundingClientRect().top + window.scrollY - 78;
  window.scrollTo({ top, behavior: reduce ? "auto" : "smooth" });
  // move focus for keyboard / screen-reader users
  window.setTimeout(
    () => {
      el.setAttribute("tabindex", "-1");
      el.focus({ preventScroll: true });
    },
    reduce ? 0 : 620
  );
}

/* ------------------------------------------------------------------ *
 *  Quote flow — CTAs prefill the contact form service field
 * ------------------------------------------------------------------ */
type QuoteCtx = {
  service: string;
  setService: (v: string) => void;
  postcode: string;
  setPostcode: (v: string) => void;
  requestQuote: (service?: string, postcode?: string) => void;
  highlight: boolean;
};

const Ctx = createContext<QuoteCtx | null>(null);

export function QuoteProvider({ children }: { children: ReactNode }) {
  const [service, setService] = useState("");
  const [postcode, setPostcode] = useState("");
  const [highlight, setHighlight] = useState(false);
  const timer = useRef<number | undefined>(undefined);

  const requestQuote = useCallback((s?: string, pc?: string) => {
    if (s) setService(s);
    if (pc) setPostcode(pc);
    scrollToId("contact");
    setHighlight(true);
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setHighlight(false), 2200);
  }, []);

  useEffect(() => () => window.clearTimeout(timer.current), []);

  const value = useMemo(
    () => ({ service, setService, postcode, setPostcode, requestQuote, highlight }),
    [service, postcode, requestQuote, highlight]
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useQuote() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useQuote must be used inside QuoteProvider");
  return ctx;
}

/* ------------------------------------------------------------------ *
 *  Misc hooks
 * ------------------------------------------------------------------ */
export function useScrolled(offset = 12) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > offset);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [offset]);
  return scrolled;
}

export function useLockBody(locked: boolean) {
  useEffect(() => {
    if (!locked) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [locked]);
}
