export const px = (id: number, w: number, h: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;

/**
 * ─────────────────────────────────────────────────────────────
 *  EDIT ME: Becky's real contact details go here.
 *  While these are empty the site shows clear [placeholders] and
 *  the phone / email buttons stay disabled so nothing is invented.
 * ─────────────────────────────────────────────────────────────
 */
export const CONTACT = {
  phone: "", // e.g. "07000 000000"
  email: "", // e.g. "hello@example.com"
  whatsapp: "", // e.g. "07000 000000"
  base: "Bristol, UK",
};

export const PHONE_PLACEHOLDER = "[PHONE NUMBER]";
export const EMAIL_PLACEHOLDER = "[EMAIL ADDRESS]";

export const phoneHref = CONTACT.phone ? `tel:${CONTACT.phone.replace(/[^\d+]/g, "")}` : undefined;
export const emailHref = CONTACT.email ? `mailto:${CONTACT.email}` : undefined;

export const BUSINESS = {
  name: "Becky's Cleaning Services",
  short: "Becky's Cleaning",
  since: 2011,
  location: "Bristol, UK",
  strap: "Professional cleaning services in Bristol.",
};

export const NAV = [
  { id: "home", label: "Home" },
  { id: "services", label: "Services" },
  { id: "about", label: "About" },
  { id: "areas", label: "Areas We Cover" },
  { id: "pricing", label: "Pricing" },
  { id: "contact", label: "Contact" },
];

export type Service = {
  id: string;
  title: string;
  icon:
    | "houseHeart"
    | "brush"
    | "oven"
    | "key"
    | "calendarRepeat"
    | "shieldLeaf"
    | "broom"
    | "sparkle";
  blurb: string;
  intro: string;
  includes: string[];
  price: string;
  image: string;
  featured?: boolean;
};

export const SERVICES: Service[] = [
  {
    id: "house-cleaning",
    title: "House Cleaning",
    icon: "houseHeart",
    blurb: "Regular professional cleaning to keep your home fresh and tidy.",
    intro:
      "The everyday keep-it-tidy service. Beds made, floors cared for, surfaces wiped and rooms left smelling fresh — ideal if you simply want to come home to a clean house.",
    includes: [
      "Kitchen surfaces, worktops & appliance fronts",
      "Bathroom & bathroom suite scrubbed and polished",
      "Floors vacuumed, swept and mopped",
      "Dusting, tidying and bins emptied",
      "Beds made and fresh towels laid out",
    ],
    price: "From £17 per hour",
    image: px(8146213, 1000, 700),
    featured: true,
  },
  {
    id: "deep-cleaning",
    title: "Deep Cleaning",
    icon: "brush",
    blurb: "Detailed cleaning for homes that need extra attention.",
    intro:
      "A proper top-to-bottom reset. Behind the furniture, into the skirting boards, degreased and descaled — perfect for a spring clean, after renovations or a seasonal refresh.",
    includes: [
      "Degreasing kitchen cupboards inside and out",
      "Limescale and grime removed from taps, tiles & glass",
      "Skirting boards, door frames, sills and radiators",
      "Behind and under movable furniture and appliances",
      "Upholstery and mattress vacuuming with attachment",
    ],
    price: "£20 per hour",
    image: px(5591908, 1000, 700),
    featured: true,
  },
  {
    id: "oven-cleaning",
    title: "Oven Cleaning",
    icon: "oven",
    blurb: "Thorough oven cleaning to remove built-up grease and grime.",
    intro:
      "Trays, racks, glass and door seals cleaned properly, so the oven looks and works like it should again. Great on its own or added to a deep clean.",
    includes: ["Interior walls and base degreased", "Racks and trays soaked and cleaned", "Door glass and seals detailed", "Extractor filters and hob surfaces", "Backed up with gas and electric ovens"],
    price: "Quoted per oven — ask for a price",
    image: px(7214452, 1000, 700),
  },
  {
    id: "end-of-tenancy",
    title: "End of Tenancy Cleaning",
    icon: "key",
    blurb: "A detailed clean designed for moving in or moving out.",
    intro:
      "A thorough, checklist-led clean for move-outs, move-ins and lodgement returns — the whole property cleaned to let the next tenant in on day one.",
    includes: ["Whole property deep clean", "Oven, hob and appliances inside out", "Cupboards, drawers and wardrobes empty and wiped", "Windows, sills, tracks and light fittings", "Limescale, grout and marks lifted"],
    price: "Quoted per property",
    image: px(7061333, 1000, 700),
  },
  {
    id: "recurring-cleaning",
    title: "Recurring Home Cleaning",
    icon: "calendarRepeat",
    blurb: "Flexible weekly, fortnightly or monthly cleaning plans.",
    intro:
      "Same day, same hour, same standard. Choose a routine that suits your household and it just keeps getting done — no chasing, no re-booking every month.",
    includes: ["Weekly, fortnightly or monthly visits", "One-off and daily slots also available", "Consistent, familiar cleaner", "Rota adjusted around holidays and busy weeks", "Priority booking for regular customers"],
    price: "From £17 per hour",
    image: px(9462341, 1000, 700),
  },
  {
    id: "disinfection",
    title: "Disinfection & Sanitization",
    icon: "shieldLeaf",
    blurb: "Professional sanitising cleaning for a cleaner and healthier environment.",
    intro:
      "Focused on the touchpoints where germs gather — good for households with little ones, unwell family members, or anyone who simply wants extra peace of mind.",
    includes: ["High-touch points sanitised first", "Kitchen and bathroom suites sanitised", "Handles, switches, remotes and rails", "Suitable for homes with children and pets", "Appropriate dwell times observed"],
    price: "Added to any clean — ask for a quote",
    image: px(9462131, 1000, 700),
  },
];

/** Services listed in the ads that are add-on / included options rather than full cards. */
export const EXTRA_SERVICES = [
  {
    id: "general-cleaning",
    title: "General Cleaning",
    icon: "broom" as const,
    blurb: "Everyday tidying and surface care across the home.",
    price: "£17 / hour",
  },
  {
    id: "residential-cleaning",
    title: "Residential Cleaning",
    icon: "sparkle" as const,
    blurb: "Flats, houses and shared homes — occupied or empty.",
    price: "Quoted per property",
  },
];

export const FEATURES = [
  {
    icon: "badgeCheck" as const,
    title: "Experienced & Reliable",
    text: "An experienced cleaner and housekeeper, posting services in Bristol since 2011 — same standard, visit after visit.",
  },
  {
    icon: "calendarRepeat" as const,
    title: "Flexible Cleaning Schedules",
    text: "One-off, daily, weekly, fortnightly or monthly. Last-minute bookings may be available if a slot opens up.",
  },
  {
    icon: "leaf" as const,
    title: "Natural & Non-Toxic Products",
    text: "All-natural, non-toxic cleaning products used wherever suitable — kinder on worktops, and better for a healthy home.",
  },
  {
    icon: "brush" as const,
    title: "Professional Deep Cleaning",
    text: "Detailed, methodical work: degreasing, descaling and the spots that usually get skipped, done properly.",
  },
  {
    icon: "pin" as const,
    title: "Local Bristol Service",
    text: "Based here and covering BS6, BS7, BS9, BS10, BS11 and BS34 — no long travel, no unfamiliar agency staff.",
  },
  {
    icon: "tag" as const,
    title: "Personalised Quotes",
    text: "Competitive, honest pricing worked out around your home and your requirements — not a generic package.",
  },
];

export const PRICING = [
  {
    name: "General Cleaning",
    price: "£17",
    unit: "/ hour",
    line: "Regular and general household cleaning.",
    icon: "broom" as const,
    points: [
      "Whole-home tidying and surface care",
      "Kitchen and bathrooms included",
      "Floors vacuumed and mopped",
      "Ideal as a weekly or fortnightly visit",
    ],
    highlight: false,
  },
  {
    name: "Deep Cleaning",
    price: "£20",
    unit: "/ hour",
    line: "Detailed cleaning for homes requiring extra attention.",
    icon: "brush" as const,
    points: [
      "Top-to-bottom detailed clean",
      "Degreasing and limescale removal",
      "Skirting, sills, radiators, behind appliances",
      "Add oven cleaning or a move-in reset",
    ],
    highlight: true,
  },
];

export const AREAS = [
  { code: "BS6", name: "Redland, Bishopston", x: 40, y: 40 },
  { code: "BS10", name: "Westbury-on-Trym", x: 30, y: 16 },
  { code: "BS34", name: "Bedminster", x: 36, y: 72 },
  { code: "BS11", name: "Ashton, Southville", x: 18, y: 58 },
  { code: "BS7", name: "Horfield", x: 62, y: 24 },
  { code: "BS9", name: "Stoke Bishop, Sea Mills", x: 12, y: 32 },
];

export const STEPS = [
  {
    icon: "chat" as const,
    title: "Tell Us What You Need",
    text: "Get in touch and explain your cleaning requirements — the rooms involved, how busy the house is, and when suits you.",
  },
  {
    icon: "fileCheck" as const,
    title: "Get Your Quote",
    text: "Receive a personalised quote based on your property and the type of clean, with a clear hourly rate and no surprises.",
  },
  {
    icon: "sparkle" as const,
    title: "Enjoy a Cleaner Home",
    text: "Pick a convenient time and let Becky take care of the cleaning — one-off, or on a regular schedule you set.",
  },
];

export const TRUST = [
  "Serving Bristol since 2011",
  "Experienced cleaner & housekeeper",
  "Natural, non-toxic products",
  "Flexible scheduling",
  "One-off to monthly visits",
  "Personalised quotes",
];

export const TESTIMONIALS = [
  {
    label: "Demo testimonial",
    quote: "Add your customer review here.",
    hint: "Replace with a short quote from a happy customer — name or area only, with their permission.",
  },
  {
    label: "Customer review placeholder",
    quote: "Add your customer review here.",
    hint: "Deep clean, end of tenancy or recurring visit — say which service they used.",
  },
  {
    label: "Demo testimonial",
    quote: "Add your customer review here.",
    hint: "Keep it to 2–3 sentences so it reads well on a phone.",
  },
];

export const FAQS = [
  {
    q: "Do you offer regular cleaning?",
    a: "Yes. Flexible one-off, weekly, fortnightly and monthly cleaning options are available.",
  },
  {
    q: "Do you provide deep cleaning?",
    a: "Yes, deep cleaning is available at £20 per hour.",
  },
  {
    q: "What areas do you cover?",
    a: "Current listed areas include BS6, BS10, BS34, BS11, BS7 and BS9. Contact Becky if your postcode isn't listed.",
  },
  {
    q: "Do you offer end of tenancy cleaning?",
    a: "Yes, end of tenancy cleaning is one of the available services.",
  },
  {
    q: "Can I request a personalised quote?",
    a: "Yes. Contact Becky with your cleaning requirements for a personalised quote.",
  },
  {
    q: "Do you bring your own products and equipment?",
    a: "Yes — professional cleaning products are used on every visit, with all-natural, non-toxic products wherever suitable. Let us know if there is anything specific you would like used, or avoided, in your home.",
  },
  {
    q: "Can I book a last-minute clean?",
    a: "Sometimes. If there is a gap in the week, last-minute bookings may be available — send your postcode and preferred date and we will let you know what is possible.",
  },
];

export const SERVICE_OPTIONS = [
  ...SERVICES.map((s) => s.title),
  ...EXTRA_SERVICES.map((s) => s.title),
  "Not sure yet — please advise",
];
