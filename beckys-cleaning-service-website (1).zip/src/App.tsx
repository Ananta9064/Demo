import Header from "./components/Header";
import Hero from "./components/Hero";
import Services from "./components/Services";
import About from "./components/About";
import Why from "./components/Why";
import Pricing from "./components/Pricing";
import Areas from "./components/Areas";
import Process from "./components/Process";
import Testimonials from "./components/Testimonials";
import Faq from "./components/Faq";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import StickyCta from "./components/StickyCta";
import { QuoteProvider } from "./lib/ui";

export default function App() {
  return (
    <QuoteProvider>
      <a
        href="#services"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[70] focus:rounded-full focus:bg-brand-700 focus:px-5 focus:py-3 focus:text-sm focus:font-bold focus:text-white"
      >
        Skip to services
      </a>

      <Header />

      <main>
        <Hero />
        <Services />
        <About />
        <Why />
        <Pricing />
        <Areas />
        <Process />
        <Testimonials />
        <Faq />
        <Contact />
      </main>

      <Footer />
      <StickyCta />
    </QuoteProvider>
  );
}
